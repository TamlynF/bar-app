"use client";

import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import { TextStyle } from "@tiptap/extension-text-style";
import Color from "@tiptap/extension-color";
import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import {
  Bold,
  Italic,
  Underline as UnderlineIcon,
  List,
  ListOrdered,
  Undo2,
  Redo2,
  Heading1,
  Heading2,
  Pilcrow,
} from "lucide-react";

const COLORS = [
  { label: "Default", value: "" },
  { label: "White", value: "#ffffff" },
  { label: "Gold", value: "#FDCC4B" },
  { label: "Red", value: "#ef4444" },
  { label: "Green", value: "#22c55e" },
  { label: "Muted", value: "#a8a29e" },
];

type ToolbarButtonProps = {
  onClick: () => void;
  active?: boolean;
  title: string;
  children: React.ReactNode;
};

function ToolbarButton({ onClick, active, title, children }: ToolbarButtonProps) {
  return (
    <button
      type="button"
      onMouseDown={(e) => {
        e.preventDefault();
        onClick();
      }}
      title={title}
      className={cn(
        "flex h-7 w-7 items-center justify-center rounded-lg text-[#34451F] transition-colors",
        active
          ? "bg-[#34451F] text-white"
          : "hover:bg-[#D8D5C8]"
      )}
    >
      {children}
    </button>
  );
}

type RichTextEditorProps = {
  name: string;
  defaultValue?: string;
};

export function RichTextEditor({ name, defaultValue = "" }: RichTextEditorProps) {
  const hiddenRef = useRef<HTMLInputElement>(null);

  const editor = useEditor({
    extensions: [
      StarterKit,
      Underline,
      TextStyle,
      Color,
    ],
    content: defaultValue,
    immediatelyRender: false,
    onUpdate({ editor }) {
      if (hiddenRef.current) {
        hiddenRef.current.value = editor.getHTML();
      }
    },
  });

  useEffect(() => {
    if (hiddenRef.current && editor) {
      hiddenRef.current.value = editor.getHTML();
    }
  }, [editor]);

  if (!editor) return null;

  return (
    <div className="flex flex-1 flex-col gap-0">
      <input type="hidden" name={name} ref={hiddenRef} defaultValue={defaultValue} />

      <div className="flex flex-wrap items-center gap-0.5 rounded-t-2xl border-b border-[#D8D5C8] bg-[#F4F1E8] px-2 py-1.5">
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleBold().run()}
          active={editor.isActive("bold")}
          title="Bold"
        >
          <Bold className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarButton
          onClick={() => editor.chain().focus().toggleItalic().run()}
          active={editor.isActive("italic")}
          title="Italic"
        >
          <Italic className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarButton
          onClick={() => editor.chain().focus().toggleUnderline().run()}
          active={editor.isActive("underline")}
          title="Underline"
        >
          <UnderlineIcon className="h-3.5 w-3.5" />
        </ToolbarButton>

        <div className="mx-0.5 h-5 w-px bg-[#D8D5C8]" />

        <ToolbarButton
          onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
          active={editor.isActive("heading", { level: 1 })}
          title="Heading 1"
        >
          <Heading1 className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarButton
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          active={editor.isActive("heading", { level: 2 })}
          title="Heading 2"
        >
          <Heading2 className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarButton
          onClick={() => editor.chain().focus().setParagraph().run()}
          active={editor.isActive("paragraph")}
          title="Normal text"
        >
          <Pilcrow className="h-3.5 w-3.5" />
        </ToolbarButton>

        <div className="mx-0.5 h-5 w-px bg-[#D8D5C8]" />

        <ToolbarButton
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          active={editor.isActive("bulletList")}
          title="Bullet list"
        >
          <List className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarButton
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          active={editor.isActive("orderedList")}
          title="Numbered list"
        >
          <ListOrdered className="h-3.5 w-3.5" />
        </ToolbarButton>

        <div className="mx-0.5 h-5 w-px bg-[#D8D5C8]" />

        {COLORS.map((c) => (
          <button
            key={c.label}
            type="button"
            title={c.label}
            onMouseDown={(e) => {
              e.preventDefault();
              if (c.value) {
                editor.chain().focus().setColor(c.value).run();
              } else {
                editor.chain().focus().unsetColor().run();
              }
            }}
            className={cn(
              "h-5 w-5 rounded-full border-2 transition-transform hover:scale-110",
              c.value === "" && "bg-[#20231A]",
              editor.isActive("textStyle", { color: c.value }) && c.value
                ? "scale-110 border-[#34451F]"
                : "border-transparent"
            )}
            style={c.value ? { "--swatch": c.value } as React.CSSProperties : undefined}
          >
            {c.value && (
              <span
                className="block h-full w-full rounded-full"
                style={{ backgroundColor: c.value }}
              />
            )}
          </button>
        ))}

        <div className="mx-0.5 h-5 w-px bg-[#D8D5C8]" />

        <ToolbarButton
          onClick={() => editor.chain().focus().undo().run()}
          title="Undo"
        >
          <Undo2 className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarButton
          onClick={() => editor.chain().focus().redo().run()}
          title="Redo"
        >
          <Redo2 className="h-3.5 w-3.5" />
        </ToolbarButton>
      </div>

      <EditorContent
        editor={editor}
        className="rich-editor min-h-30 overflow-y-auto rounded-b-2xl bg-white px-3 py-2 text-sm leading-snug text-[#20231A] outline-none"
      />
    </div>
  );
}
