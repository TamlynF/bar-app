import { redirect } from "next/navigation";

export default function MarketingIndexPage() {
  redirect("/marketing/trends");
}
