import { AdminHubGrid } from "@/components/admin-hub-tiles";
import { WEBSITE_NAV_ITEMS } from "@/lib/admin-nav";

export default function WebsiteBasePage() {
  return (
    <div className="space-y-6 px-2 py-2 sm:px-8 sm:py-0">
      <AdminHubGrid items={WEBSITE_NAV_ITEMS} />
    </div>
  );
}
