import React from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { CalendarDays, Clock, ChevronRight, Wallet, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { badgeClassFromColor } from "@/lib/event-type-colors";
import { buildAdminBookingGroups, type AdminBookingGroupEvent } from "@/lib/admin-booking-groups";

export const dynamic = "force-dynamic";

function toTitleCase(str?: string | null) {
  if (!str) return "";
  return str.replace(/\w\S*/g, (t) => t.charAt(0).toUpperCase() + t.substring(1).toLowerCase());
}

function formatDate(dateStr: string) {
  return new Date(dateStr + "T00:00:00").toLocaleDateString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function formatTime(t?: string | null) {
  if (!t) return "";
  const [hh, mm] = t.split(":");
  const h = parseInt(hh, 10);
  const ampm = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 || 12;
  return `${h12}:${mm} ${ampm}`;
}

type Rel<T> = T | T[] | null;
function first<T>(rel: Rel<T>): T | null {
  return Array.isArray(rel) ? rel[0] ?? null : rel;
}

type RawBooking = {
  id: number;
  group_name: string | null;
  group_size: number | null;
  status: string | null;
  total_amount: number | null;
  paid_amount: number | null;
  contacts: Rel<{ full_name: string | null; email: string | null; phone_no: string | null }>;
  events: Rel<{
    id: number;
    date: string;
    start_time: string | null;
    title: string | null;
    is_active: boolean | null;
    event_types: Rel<{ name: string; booking_grouping: string | null }>;
    event_subtypes: Rel<{ name: string; color: string | null; behavior: string | null }>;
  }>;
};

type UnpaidBooking = {
  id: number;
  groupName: string;
  guests: number;
  total: number;
  paid: number;
  outstanding: number;
  contactName: string;
};

type EventGroup = {
  eventId: number;
  date: string;
  startTime: string | null;
  title: string;
  typeName: string;
  subName: string;
  color: string | null;
  href: string;
  bookings: UnpaidBooking[];
  outstanding: number;
};

export default async function UnpaidBookingsPage() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("bookings")
    .select(`
      id,
      group_name,
      group_size,
      status,
      total_amount,
      paid_amount,
      contacts!bookings_contact_id_fkey(full_name, email, phone_no),
      events!bookings_event_id_fkey!inner(
        id, date, start_time, title, is_active,
        event_types!inner(name, booking_grouping),
        event_subtypes!inner(name, color, behavior)
      )
    `)
    .eq("status", "confirmed")
    .gt("total_amount", 0)
    .eq("events.is_active", true)
    .order("date", { referencedTable: "events", ascending: true });

  if (error) console.error("Unpaid bookings query error:", error);

  const rows = (data ?? []) as unknown as RawBooking[];

  const groupMap = new Map<number, EventGroup>();
  for (const b of rows) {
    const ev = first(b.events);
    if (!ev) continue;
    const total = b.total_amount ?? 0;
    const paid = b.paid_amount ?? 0;
    if (paid >= total) continue;

    if (!groupMap.has(ev.id)) {
      const et = first(ev.event_types);
      const es = first(ev.event_subtypes);
      const group = buildAdminBookingGroups([ev as unknown as AdminBookingGroupEvent])[0];
      const base = group?.href ?? `/event-bookings/event/${ev.id}`;
      const href =
        group?.grouping === "per_type" || group?.grouping === "per_subtype"
          ? `${base}?eventId=${ev.id}&status=confirmed`
          : `${base}?status=confirmed`;
      groupMap.set(ev.id, {
        eventId: ev.id,
        date: ev.date,
        startTime: ev.start_time,
        title: ev.title ?? "Untitled Event",
        typeName: et?.name ?? "",
        subName: es?.name ?? "",
        color: es?.color ?? null,
        href,
        bookings: [],
        outstanding: 0,
      });
    }
    const group = groupMap.get(ev.id)!;
    const contact = first(b.contacts);
    const outstanding = total - paid;
    group.bookings.push({
      id: b.id,
      groupName: b.group_name || contact?.full_name || "Unnamed booking",
      guests: b.group_size ?? 0,
      total,
      paid,
      outstanding,
      contactName: contact?.full_name ?? "",
    });
    group.outstanding += outstanding;
  }

  const groups = Array.from(groupMap.values())
    .map((g) => ({
      ...g,
      bookings: g.bookings.sort((a, b) => b.outstanding - a.outstanding),
    }))
    .sort((a, b) => a.date.localeCompare(b.date));

  const totalOutstanding = groups.reduce((s, g) => s + g.outstanding, 0);
  const totalBookings = groups.reduce((s, g) => s + g.bookings.length, 0);

  return (
    <div className="min-h-screen flex-1 bg-background">
      <div className="mx-auto max-w-4xl space-y-4 px-3 py-3 sm:py-0 md:px-8">

        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="font-black text-xl tracking-tight text-[#20231A] uppercase">Unpaid Bookings</h2>
            <p className="mt-0.5 text-xs text-[#5E6654]">
              Confirmed bookings with an outstanding balance on active events, grouped by event.
            </p>
          </div>
        </div>

        <div className="flex items-stretch gap-3 rounded-2xl border border-[#D8D5C8] bg-white p-3 shadow-sm">
          <div className="flex flex-1 flex-col items-center justify-center gap-0.5">
            <span className="font-black text-[10px] tracking-wide text-[#5E6654] uppercase opacity-60">Outstanding</span>
            <span className={cn("font-black text-lg tabular-nums", totalOutstanding > 0 ? "text-[#9A5B00]" : "text-[#5E6654]")}>
              £{totalOutstanding.toFixed(2)}
            </span>
          </div>
          <div className="w-px self-stretch bg-[#D8D5C8]" />
          <div className="flex flex-1 flex-col items-center justify-center gap-0.5">
            <span className="font-black text-[10px] tracking-wide text-[#5E6654] uppercase opacity-60">Bookings</span>
            <span className="font-black text-lg text-[#20231A] tabular-nums">{totalBookings}</span>
          </div>
          <div className="w-px self-stretch bg-[#D8D5C8]" />
          <div className="flex flex-1 flex-col items-center justify-center gap-0.5">
            <span className="font-black text-[10px] tracking-wide text-[#5E6654] uppercase opacity-60">Events</span>
            <span className="font-black text-lg text-[#20231A] tabular-nums">{groups.length}</span>
          </div>
        </div>

        {groups.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-[#D8D5C8] bg-white p-10 text-center">
            <div className="rounded-2xl bg-[#F4F1E8] p-3">
              <Wallet className="h-6 w-6 text-[#34451F] opacity-30" />
            </div>
            <p className="font-black text-sm text-[#20231A]">Nothing outstanding</p>
            <p className="max-w-64 text-[11px] leading-relaxed text-[#5E6654]">
              Every confirmed booking on an active event is fully paid.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {groups.map((g) => (
              <section key={g.eventId} className="overflow-hidden rounded-2xl border border-[#D8D5C8] bg-white shadow-sm">
                <Link
                  href={g.href}
                  className="flex items-center gap-3 border-b border-[#D8D5C8] px-4 py-3 transition-colors hover:bg-[#F4F1E8]"
                >
                  <div className="flex h-11 w-11 shrink-0 flex-col items-center justify-center rounded-xl bg-[#F4F1E8]">
                    <CalendarDays className="h-4 w-4 text-[#34451F] opacity-60" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="mb-0.5 flex flex-wrap items-center gap-1.5">
                      {g.subName && (
                        <span className={cn("rounded px-1.5 py-0.5 font-black text-[9px] tracking-wide uppercase", badgeClassFromColor(g.color))}>
                          {toTitleCase(g.subName)}
                        </span>
                      )}
                    </div>
                    <p className="truncate font-black text-sm leading-tight text-[#20231A]">{g.title}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-2.5 text-[11px] font-semibold text-[#5E6654]">
                      <span className="inline-flex items-center gap-1">
                        <CalendarDays className="h-3 w-3" />{formatDate(g.date)}
                      </span>
                      {g.startTime && (
                        <span className="inline-flex items-center gap-1">
                          <Clock className="h-3 w-3" />{formatTime(g.startTime)}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-0.5">
                    <span className="font-black text-sm text-[#9A5B00] tabular-nums">£{g.outstanding.toFixed(2)}</span>
                    <span className="text-[10px] font-bold tracking-wide text-[#5E6654] uppercase opacity-60">owed</span>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-[#5E6654] opacity-40" />
                </Link>

                <ul className="divide-y divide-[#D8D5C8]/60">
                  {g.bookings.map((bk) => (
                    <li key={bk.id} className="flex items-center gap-3 px-4 py-2.5">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-bold text-[#20231A]">{bk.groupName}</p>
                        <div className="mt-0.5 flex items-center gap-2.5 text-[11px] font-semibold text-[#5E6654]">
                          <span className="inline-flex items-center gap-1">
                            <Users className="h-3 w-3" />{bk.guests}
                          </span>
                          <span className="tabular-nums">
                            £{bk.paid.toFixed(2)} <span className="opacity-50">/ £{bk.total.toFixed(2)}</span>
                          </span>
                        </div>
                      </div>
                      <span className="shrink-0 font-black text-[13px] text-[#9A5B00] tabular-nums">
                        £{bk.outstanding.toFixed(2)}
                      </span>
                    </li>
                  ))}
                </ul>
              </section>
            ))}
          </div>
        )}

      </div>
    </div>
  );
}
