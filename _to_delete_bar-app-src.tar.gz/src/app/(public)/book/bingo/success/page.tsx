import type { Viewport } from "next";
import { createClient } from "@/lib/supabase/server";
import { squareClient } from "@/lib/square";
import { settlePaidBooking } from "@/lib/settle-paid-booking";
import { CheckCircle2, XCircle, Clock, AlertTriangle } from "lucide-react";
import Link from "next/link";
import { Resend } from "resend";
import RetryPaymentButton from "@/components/retry-payment-button";
import { buildBookingConfirmedEmail, formatEventDate } from "@/lib/booking-emails";
import { renderTemplate } from "@/lib/email/resolve";
import { EMAIL_FROM } from "@/lib/email";
import { getContactEmail } from "@/lib/company-info";

export const viewport: Viewport = {
  themeColor: "#26300D",
};

const resend = new Resend(process.env.RESEND_API_KEY);

const appUrl = process.env.NEXT_PUBLIC_SITE_URL
  ? process.env.NEXT_PUBLIC_SITE_URL
  : process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : "http://localhost:3000";

async function confirmAndNotify(bookingId: string) {
  const supabase = await createClient();

  const { data: booking } = await supabase
    .from("bookings")
    .select(`
      id, status, payment_status, group_name, group_size, total_amount, square_order_id,
      contacts!bookings_contact_id_fkey(full_name, email),
      events!bookings_event_id_fkey(date, title)
    `)
    .eq("id", bookingId)
    .maybeSingle();
console.log("Booking fetcheddd:", booking);
  if (!booking) {
    console.log("Booking not found for ID:", bookingId);
    return { status: "not_found" as const };
  }
  if (booking.payment_status === "paid") {
    console.log("Booking already paid for ID:", bookingId);
    return { status: "already_paid" as const, booking };
  }

  if (!booking.square_order_id) {
    console.log("Booking has no Square order ID:", bookingId);
    return { status: "pending" as const, booking };
  }
  try {
    const { order } = await squareClient.orders.get({ orderId: booking.square_order_id });
    console.log("order fetched from Square:", order);

    const tender = order?.tenders?.[0];
    if (!tender) {
      console.log("No tenders found - payment not yet applied for booking ID:", bookingId);
      return { status: "pending" as const, booking };
    }

    const squarePaymentId = tender?.id ?? null;
    const paidAmount = tender?.amountMoney?.amount
      ? Number(tender.amountMoney.amount) / 100
      : (booking.total_amount ?? 0);

    const settlement = await settlePaidBooking(supabase, {
      bookingId,
      paidAmount,
      squarePaymentId,
    });

    if (settlement.outcome === "settled" && settlement.status === "waitlisted") {
      return { status: "waitlisted" as const, booking };
    }

    const contactRaw = booking.contacts;
    const contact = (Array.isArray(contactRaw) ? contactRaw[0] : contactRaw) as { full_name: string; email: string } | null;
    const eventRaw = booking.events;
    const event = (Array.isArray(eventRaw) ? eventRaw[0] : eventRaw) as { date: string; title: string } | null;
    if (contact?.email) {
      const manageUrl = `${appUrl}/book/bingo/manage-booking/${booking.id}`;

      const partySize = `${booking.group_size} ${booking.group_size === 1 ? "Person" : "People"}`;

      const slots = await renderTemplate(supabase, "booking.bingo.confirmed", {
        customerName: contact.full_name,
        eventTitle: event?.title ?? "Music Bingo",
        eventDate: formatEventDate(event?.date ?? null),
        groupName: contact.full_name,
        groupSize: partySize,
        bookingId: String(booking.id),
        contactEmail: await getContactEmail(),
      });

      if (slots) {
        const { subject, html } = buildBookingConfirmedEmail({
          slots,
          rows: [
            { label: "📅 Date", value: formatEventDate(event?.date ?? null) },
            { label: "👥 People", value: partySize },
            { label: "💳 Paid", value: `£${(booking.total_amount ?? 0).toFixed(2)}` },
          ],
          manageUrl,
        });

        await resend.emails.send({
          from: EMAIL_FROM,
          to: contact.email,
          subject,
          html,
        }).catch(() => {});
      }
    }

    return { status: "paid" as const, booking };
  } catch (err) {
    console.error("Square order check failed:", err);
    return { status: "pending" as const, booking };
  }
}

export default async function BingoSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ bookingId?: string }>;
}) {
  const { bookingId } = await searchParams;

  if (!bookingId) {
    return <ErrorPage message="No booking reference found." />;
  }

  const result = await confirmAndNotify(bookingId);

  if (result.status === "not_found") {
    return <ErrorPage message="Booking not found. Please contact us." />;
  }

  const booking = result.booking!;
  const contactRaw2 = booking.contacts;
  const contact = (Array.isArray(contactRaw2) ? contactRaw2[0] : contactRaw2) as { full_name: string; email: string } | null;
  const eventRaw2 = booking.events;
  const event = (Array.isArray(eventRaw2) ? eventRaw2[0] : eventRaw2) as { date: string; title: string } | null;
  const eventDate = event?.date
    ? new Date(event.date).toLocaleDateString("en-GB", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric",
      })
    : "TBC";

  if (result.status === "pending") {
    return (
      <StatusPage
        icon={<AlertTriangle className="h-10 w-10 text-amber-500" />}
        color="amber"
        title="Payment Not Completed"
        message="We haven't received a payment for this booking, so your spot isn't secured yet. Nothing has been charged - you can try again below."
        eventDate={eventDate}
        groupSize={booking.group_size}
        name={contact?.full_name}
        total={booking.total_amount}
        action={<RetryPaymentButton bookingId={booking.id} amount={booking.total_amount} />}
      />
    );
  }

  if (result.status === "waitlisted") {
    return (
      <StatusPage
        icon={<Clock className="h-10 w-10 text-amber-500" />}
        color="amber"
        title="You're on the Waitlist"
        message="Your payment went through, but the last table for this night was taken while you were checking out. We'll contact you to sort out a table or a refund."
        eventDate={eventDate}
        groupSize={booking.group_size}
        name={contact?.full_name}
        total={booking.total_amount}
      />
    );
  }

  return (
    <StatusPage
      icon={<CheckCircle2 className="h-10 w-10 text-green-500" />}
      color="green"
      title="Booking Confirmed!"
      message={`You're all set${contact?.full_name ? `, ${contact.full_name}` : ""}! A confirmation has been sent to ${contact?.email ?? "your email"}.`}
      eventDate={eventDate}
      groupSize={booking.group_size}
      name={contact?.full_name}
      total={booking.total_amount}
    />
  );
}

function StatusPage({
  icon,
  color,
  title,
  message,
  eventDate,
  groupSize,
  total,
  action,
}: {
  icon: React.ReactNode;
  color: "green" | "amber";
  title: string;
  message: string;
  eventDate: string;
  groupSize?: number;
  name?: string;
  total?: number | null;
  action?: React.ReactNode;
}) {
  const borderColor = color === "green" ? "border-green-200" : "border-amber-200";
  const bgColor = color === "green" ? "bg-green-50" : "bg-amber-50";

  return (
    <main className="flex min-h-dvh w-full flex-col items-center justify-center bg-[#26300D] px-4 py-12">
      <style dangerouslySetInnerHTML={{
        __html: `html, body { background-color: #26300D !important; margin: 0; padding: 0; }`
      }} />
      <div className="w-full max-w-md rounded-3xl bg-[#F7F4EA] p-8 text-center shadow-2xl shadow-black/40">
        <div className={`inline-flex h-20 w-20 items-center justify-center rounded-full border-2 ${bgColor} ${borderColor} mb-6`}>
          {icon}
        </div>
        <h1 className="mb-3 font-black text-2xl tracking-tight text-[#1F1F1A] uppercase">
          {title}
        </h1>
        <p className="mb-6 text-sm leading-relaxed font-medium text-[#5F624F]">
          {message}
        </p>

        <div className="mb-6 divide-y-2 divide-[#E6DFC8] rounded-2xl border-2 border-[#E6DFC8] bg-white text-left">
          <div className="px-5 py-3.5">
            <p className="mb-0.5 font-black text-[10px] tracking-widest text-[#5F624F] uppercase">Event</p>
            <p className="font-black text-sm text-[#1F1F1A]">Music Bingo</p>
          </div>
          <div className="px-5 py-3.5">
            <p className="mb-0.5 font-black text-[10px] tracking-widest text-[#5F624F] uppercase">Date</p>
            <p className="font-black text-sm text-[#1F1F1A]">{eventDate}</p>
          </div>
          {groupSize && (
            <div className="px-5 py-3.5">
              <p className="mb-0.5 font-black text-[10px] tracking-widest text-[#5F624F] uppercase">People</p>
              <p className="font-black text-sm text-[#1F1F1A]">{groupSize}</p>
            </div>
          )}
          {total != null && (
            <div className="px-5 py-3.5">
              <p className="mb-0.5 font-black text-[10px] tracking-widest text-[#5F624F] uppercase">
                {action ? "Amount Due" : "Paid"}
              </p>
              <p className="font-black text-sm text-[#1F1F1A]">£{total.toFixed(2)}</p>
            </div>
          )}
        </div>

        {action}
        <Link
          href="/book"
          className={
            action
              ? "inline-block h-14 w-full rounded-2xl border-2 border-[#E6DFC8] text-center font-black text-[11px] leading-13 tracking-widest text-[#5F624F] uppercase"
              : "inline-block h-14 w-full rounded-2xl bg-[#26300D] text-center font-black text-[11px] leading-14 tracking-widest text-[#FDCC4B] uppercase shadow-lg"
          }
        >
          Back to Bookings
        </Link>
      </div>
    </main>
  );
}

function ErrorPage({ message }: { message: string }) {
  return (
    <main className="flex min-h-dvh w-full flex-col items-center justify-center bg-[#26300D] px-4 py-12">
      <style dangerouslySetInnerHTML={{
        __html: `html, body { background-color: #26300D !important; }`
      }} />
      <div className="w-full max-w-md rounded-3xl bg-[#F7F4EA] p-8 text-center shadow-2xl">
        <XCircle className="mx-auto mb-4 h-12 w-12 text-red-500" />
        <h1 className="mb-3 font-black text-xl tracking-tight text-[#1F1F1A] uppercase">
          Something went wrong
        </h1>
        <p className="mb-6 text-sm font-medium text-[#5F624F]">{message}</p>
        <Link
          href="/book/bingo"
          className="inline-block h-14 w-full rounded-2xl bg-[#26300D] text-center font-black text-[11px] leading-14 tracking-widest text-[#FDCC4B] uppercase"
        >
          Try Again
        </Link>
      </div>
    </main>
  );
}
