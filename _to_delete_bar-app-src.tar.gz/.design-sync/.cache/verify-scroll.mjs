import { chromium } from "playwright";

const URL = "http://localhost:3000/book";

const browser = await chromium.launch({ headless: true });
const ctx = await browser.newContext({
  viewport: { width: 1280, height: 720 },
  reducedMotion: "no-preference", // ensure Lenis actually runs
});
const page = await ctx.newPage();
await page.goto(URL, { waitUntil: "networkidle" });

// Let Lenis mount (it inits in a useEffect + rAF)
await page.waitForTimeout(800);

const pre = await page.evaluate(() => ({
  htmlClass: document.documentElement.className,
  lenisHeight: getComputedStyle(document.documentElement).height, // lenis.css forces html.lenis -> height:auto
  scrollHeight: document.documentElement.scrollHeight,
  innerHeight: window.innerHeight,
  scrollY: window.scrollY,
}));

await page.screenshot({ path: ".design-sync/.cache/book-top.png" });

// Real mouse wheel — this is what Lenis intercepts
await page.mouse.move(640, 360);
await page.mouse.wheel(0, 1500);
await page.waitForTimeout(1200); // Lenis animates via rAF, give it time to settle

const post = await page.evaluate(() => window.scrollY);
await page.screenshot({ path: ".design-sync/.cache/book-after-wheel.png" });

console.log(JSON.stringify({
  hasLenisClass: pre.htmlClass.includes("lenis"),
  computedHtmlHeight: pre.lenisHeight,
  scrollable: pre.scrollHeight > pre.innerHeight,
  scrollHeight: pre.scrollHeight,
  innerHeight: pre.innerHeight,
  scrollYBefore: pre.scrollY,
  scrollYAfterWheel: post,
  wheelScrolled: post > pre.scrollY + 50,
}, null, 2));

await browser.close();
