# Handoff: Event Categories redesign (Option B)

Target file: `src/app/(private)/event-setups/event-types/event-types-client.tsx` in **TamlynF/bar-app** (branch `production`).

## Overview

The Event Categories admin screen was one long, dense page: nested category/sub-category rows, colour dots with no legend, jargon labels ("behaviour", "grouping", "per_subtype"), and one enormous edit dialog holding every setting at once. Non-technical bar staff could not tell what any field did or what would show to customers.

This redesign restructures the same data and the same server actions into:

- a **two-pane explorer** (categories left, sub-categories right) that collapses to a drill-down on phones;
- a **tabbed edit sheet** (5 tabs) instead of one long dialog, with the Booking tab appearing only when the sub-category is bookable;
- **plain-English labels and help** on every field - a short grey hint line always visible, plus an "i" button with a longer explanation written for someone who does not use websites.

No schema or action changes are implied. Every control maps to an existing field.

## About the design files

The files in this bundle are **design references created in HTML** - browser-React prototypes showing intended look and behaviour. They are *not* production code to copy. `ec-option-b.jsx` uses `React.createElement` via in-browser Babel, inline styles, and a hand-rolled icon set purely so the prototype runs from a static file.

**The task is to recreate these designs in bar-app's existing environment**: Next.js App Router + TypeScript, Tailwind, shadcn/ui primitives (`Button`, `Input`, `Sheet`, `Dialog`, `Tabs`, `Switch`, `Tooltip`, `Popover`), `lucide-react` icons, and the existing server actions in `actions.ts`. Use the codebase's own components everywhere a prototype hand-rolls one (see "Prototype → codebase mapping").

## Fidelity

**High fidelity.** Colours, type sizes, spacing, radii, copy and interaction states below are final and exact. Recreate pixel-faithfully using existing Tailwind tokens and shadcn primitives - do not re-derive the visual language.

Exception: iconography in the prototype is a hand-drawn 24×24 stroke set. Substitute the `lucide-react` equivalents named in the icon table.

---

## Screens / views

### 1. Category explorer (wide, ≥900px)

**Purpose:** browse categories, see the sub-categories inside one, jump to editing.

**Layout**
- Page shell: full-height column. Top app bar (48px tall, `bg-card`, 1px bottom border `#E6DFC8`) with breadcrumb "Events / **Event categories**" - 12px, uppercase, letter-spacing .14em, muted; the last crumb bold and ink-coloured.
- Content wrapper: `max-width: 1180px`, centred, padding `26px 24px 80px`.
- Header row: flex, wrap, `align-items: flex-end`, `justify-content: space-between`, 14px gap, 18px bottom margin. Left: H1 "Event categories" (24px, Archivo Black, letter-spacing -.01em) + sub-line "Pick a category on the left to see the nights inside it." (13.5px, muted, max-width 60ch, line-height 1.5). Right: primary button "+ New category".
- Body: CSS grid, `grid-template-columns: clamp(230px,25%,290px) 1fr`, gap 18px, `align-items: start`.

**Left pane - category list**
- Card: `bg-card #FFFDF7`, 1px border `#E6DFC8`, radius 14px, padding 8px, `position: sticky; top: 16px`.
- Eyebrow "Categories": 10.5px, uppercase, letter-spacing .16em, weight 700, muted, padding `8px 6px 6px`.
- Rows (2px gap): flex, gap 11px, padding `12px 13px`, radius 12px, 1px transparent border. Content: 10px colour dot (the category's colour) · name (14px Archivo Black) with "N sub-categories" beneath (12px muted) · chevron rotated -90°.
  - Selected: border `#5C4033`, background `#F1E9E2`, `aria-current="true"`.
- Footer: ghost button "+ Add a category", full width, 34px tall.

**Right pane - category detail**
- Header card (padding 14px, 12px gap, column):
  - Title row: 12px colour dot · category name (18px Archivo Black, flex-1) · edit icon button · delete icon button.
  - Website sentence: 13px muted, line-height 1.5, with bold ink lead-in - "**On the website:** Every date gets its own page on the website." (text varies by grouping; see Grouping table).
  - Tool row: search field (flex 1 1 200px, 44px tall, radius 12px, 1px border, magnifier icon + placeholder "Search in Games") and primary button "+ Add a night".
- Sub-category cards: grid `repeat(auto-fill, minmax(min(100%,340px), 1fr))`, gap 12px → two columns from ~1100px.
- Empty state: card, 44px vertical padding, centred, layers icon 22px, "Nothing in here yet" (14px Archivo Black), "Add a night to get started." (12.5px muted).

**Sub-category card**
- Card, padding 14px, column, 11px gap.
- Top row: 38px rounded-10px tile filled with the sub-category colour's `bg` and `text` (see Colour table), holding the behaviour icon at 18px · name (15.5px Archivo Black) with "Website name: **Quiz Night**" beneath (12.5px muted, the value bold ink; falls back to "No website name set") · edit + delete icon buttons.
- Fact chips (see Fact chips) wrapping at 6px gap.
- Badge strip, only if badges exist: 1px top border `#EFEADB`, 10px top padding, chips of icon + bold title + "· desc".

### 2. Category explorer (phone, <900px)

Same data, one pane.

- Root list: header + sub-line ("Tap a category to see the nights inside it.") + the category rows, full width. No sidebar card styling change needed - same rows, same 48px+ targets.
- Drilled in: the header/list is replaced by the detail pane, and a **sticky context header** appears at the top: 8px/12px padding, `rgba(255,253,247,.94)` + `backdrop-filter: blur(6px)`, 1px bottom border, `z-index: 40`. Contents: back arrow icon button · 10px colour dot · category name (16px Archivo Black, truncated with ellipsis) · edit icon button. The desktop title row inside the detail card is hidden here (it would duplicate).
- **Fixed bottom action bar**: `position: fixed; inset-inline: 0; bottom: 0; z-index: 45`, padding `10px 12px calc(10px + env(safe-area-inset-bottom))`, `rgba(255,253,247,.96)` + blur(8px), 1px top border. One full-width `size="lg"` button whose label states the action in context: "+ New category" on the root list, "+ Add a night to Games" when inside a category. Content wrapper gets `padding-bottom: 88px` so the bar never covers the last card.
- Cards go single-column.

### 3. Edit sheet - sub-category

**Presentation:** a **bottom sheet, centred on the page** at every width (this was an explicit request - do not use a right-hand drawer).
- Scrim: `rgba(31,31,26,.42)`, fixed inset, `z-index: 100`, flex. Phone: `align-items: flex-end`. ≥700px: `align-items: center`, 24px padding.
- Sheet: flex column, width 100%, `max-height: 92vh`, background `#F7F4EA`, 1px border, radius `20px 20px 0 0` on phone; ≥700px `max-width: 620px`, `max-height: 88vh`, radius 20px all round. Enter animation `sheetUp`: `translateY(24px) → 0`, 220ms `cubic-bezier(.2,.7,.2,1)`.
- Grab handle: 44×4px, radius 99px, `#E6DFC8`, centred, 8px top margin.
- Head: `bg-card`, 1px bottom border, padding `16px 16px 14px`, flex. Eyebrow "Sub-category in Games" (10.5px uppercase muted) over title (18px Archivo Black). Close icon button on the right.
- Tab row: `bg-card`, `display:flex; flex-wrap: wrap; gap: 4px`, padding `0 12px 10px`. **Must wrap, never horizontally scroll** - a scrolling row cut "Booking form" in half. Each tab: 8px/11px padding, radius 9px, 12.5px weight 700, muted; a dimmed (opacity .55) step number precedes the label. Selected: background `#F1E9E2`, colour `#5C4033`, `aria-selected="true"`.
- Body: `flex: 1; min-height: 0; overflow-y: auto`, padding 16px, column, 14px gap. **This is the only scroll container.**
- Foot: `bg-card`, 1px top border, padding `12px 16px`. Phone: two full-width buttons. ≥700px: right-aligned, each `min-width: 140px`. Left "Cancel" (secondary), right either "Next: <tab name>" or, on the last tab, "Create" / "Save changes". Save is disabled while the name is empty.

**Tabs**
1. **Name** - Short name (required), Website name, Fills in new events as, Colour in your lists.
2. **Kind of night** - the behaviour picker.
3. **What it needs** - four question toggles + conditional price.
4. **Website** - tagline, poster picture, badges, plus a live preview box.
5. **Booking form** - rendered **only when "Can customers book it online?" is on**. If the user is on this tab and turns bookable off, fall back to tab 1.

#### Tab 1 - Name
| Label | Control | Placeholder | Always-visible hint | Tooltip ("i") |
|---|---|---|---|---|
| Short name *(required)* | text | `e.g. Quiz` | One or two words. Team only. | The short name your team sees in lists and on the rota. Keep it to one or two words, like "Quiz". |
| Website name | text | `e.g. Quiz Night` | What customers read when they book. | The heading customers read on the website when they book. It can be longer and friendlier, e.g. "Thursday Quiz Night". |
| Fills in new events as | text | `e.g. Thursday Quiz Night` | Saves retyping it every week. | When you add a new event of this kind, the name is filled in for you. You can still change it for a one-off. |
| Colour in your lists | swatch grid | - | Team only - never shown to customers. | Only for you and your team - the colour this shows as in your lists and calendar. It does not appear on the website. |

Validation: empty short name shows "Give it a short name so your team can find it." in `#B4453C`, 12px, weight 600, and disables the save/next action.

#### Tab 2 - Kind of night
Grid `repeat(auto-fit, minmax(150px, 1fr))`, 9px gap. Each option: flex, 9px gap, 11px padding, radius 12px, 1px border `#E6DFC8`, background `#FBF8F0`, left icon 18px in espresso, then bold 13px label and 11.5px muted blurb. Selected: border `#5C4033`, background `#F1E9E2`, `box-shadow: 0 0 0 2px rgba(92,64,51,.14)`, `aria-pressed="true"`.

| value | Label | Blurb | Icon |
|---|---|---|---|
| `standard` | Standard night | No extra tools - just a normal event. | sparkles |
| `quiz` | Quiz | Adds rounds, teams and scoring. | trophy |
| `bingo` | Bingo | Adds bingo cards and number calling. | disc |
| `karaoke` | Karaoke | Adds a singer sign-up list. | mic |
| `music_act` | Live music | Adds act details and set times. | music |
| `private` | Private hire | For bookings of the room by one group. | users |

Field help: "Tells the system what extra tools to switch on - quiz rounds, bingo numbers, a karaoke sign-up sheet, and so on." Hint: "Decides which extra tools you get."

#### Tab 3 - What it needs
Each is a question label (12.5px weight 700) + "i", then a full-width pressable row: 12px padding, radius 12px, 1px border, background `#FBF8F0`, holding a bold state line and a muted sub-line, with a 46×28px switch on the right (knob 22px, travel 18px, 180ms). On: border `#C3D8CC`, background `#EAF1EC`, track `#1B4332`.

| Question | On state / sub-line | Off state / sub-line | Tooltip |
|---|---|---|---|
| Can customers book it online? | Yes - bookable on the website / A booking page is created for it. | No - phone or walk-in only / You can still add bookings by hand. | On: customers can reserve a place online. Off: they must ring or turn up (you can still add bookings by hand). |
| Does someone have to run it? | Yes - a host is needed / You'll be asked who is hosting each date. | No host needed | Tick if someone has to run this night. You will be asked who is hosting each time you schedule one. |
| Are guests given tables? | Yes - seated / Tables are allocated when people book. | No - standing | Tick if guests are given tables. Leave it off for stand-up nights so you are not asked to allocate seats. |
| Do people pay to book? | Yes - paid entry | Free to book | Tick if people pay when booking. You then set the price below. |

When "Do people pay to book?" is on, reveal **Price per person (£)** - number input, placeholder `5.00`, hint "What one person pays to book.", tooltip "What one person pays to book. Leave at 0 if the night is free but you still want names."

#### Tab 4 - Website
- **One line to sell it** - textarea (min-height 78px, resize vertical), placeholder "Six rounds, one winner, plenty of arguing.", hint "One line, on the website under the title.", tooltip "One short line under the title on the website that sells the night. Think of what you would shout across the bar."
- **Poster picture** - dropzone button: 22px vertical padding, 1.5px dashed border `#E6DFC8`, radius 12px, background `#FBF8F0`, column, centred, 6px gap: image icon 22px, "CHOOSE A PICTURE" (12.5px Archivo Black, uppercase, letter-spacing .08em), "Used when an event has no picture of its own" (11.5px). Hint "Optional. Used when an event has no picture." Tooltip "The photo or poster used on the website whenever an event of this kind has no picture of its own."
- **Badges** - list of rows (1px border, radius 12px, background `#FBF8F0`, 10px padding): 32px rounded-9px `#F1E9E2` tile with the badge icon in espresso · bold 13px title with 11.5px muted description · red trash icon button. Below: quiet button "+ Add a badge". Empty copy: "No badges yet. Most nights look good with two, like 'Free entry' and 'Thursdays 7pm'." Hint "Two or three short facts is plenty." Tooltip "Short facts shown on the booking page, e.g. 'Free entry' or 'Thursdays 7pm'. Two or three is plenty."
- **Preview box** - 1px border, radius 12px, `#FBF8F0`, 12px padding, column 8px gap: eyebrow "How it will look", the website name (16px Archivo Black), the tagline (13px muted), then the badge chips. Read-only.

#### Tab 5 - Booking form (bookable only)
Three sections, each a card with a `#FBF8F0` header strip (1px bottom border `#EFEADB`, 12px/14px padding) carrying a 13px uppercase Archivo Black title (letter-spacing .1em) and a 12px muted blurb, and a 14px-padded body with 14px gaps.

**Booking card** - "The tile customers tap on the booking page."
Leading note: "Leave a box blank and it falls back to the website name, a calendar icon and the automatic label."
| Field | Control | Placeholder | Hint | Tooltip |
|---|---|---|---|---|
| Card title | text | the website name | Blank = the website name. | The heading on the tile customers tap. Leave blank to use the website name. |
| Card tagline | textarea | Book a table for our weekly quiz night. Eight rounds, great prizes, and happy hour vibes. | One or two sentences. | A sentence or two on the tile telling people what the night is. |
| Card note | text | `Thursdays` | Optional, e.g. "Thursdays". | A short word or two in the corner of the tile, like "Thursdays" or "Popular". Leave blank for none. |
| Card icon | icon grid | - | - | The little picture on the tile. Pick whatever looks closest to the night. |

Icon grid: `repeat(auto-fill, minmax(52px, 1fr))`, 8px gap, each cell 48px tall, radius 11px, 1.5px border `#E6DFC8`, white, icon 18px muted. Selected: border + icon `#1B4332`, background `#EAF1EC`. Options in order: calendar, map-pin, clock, sticky-note, users, star, check, music, trophy, disc, mic, ticket, globe, sparkles.

**Booking page** - "The page people land on after tapping the card."
| Field | Control | Hint | Tooltip |
|---|---|---|---|
| Booking image (logo) | dropzone (same as poster; sub-line "JPG or PNG from your phone or computer") | Optional. Shown across the top of the page. | A logo or poster shown at the top of the booking page - handy for a sponsor. |
| Tagline | text, placeholder "Description shown under the logo" | Shown under the logo. | One line under the logo on the booking page. |

**Form fields** - "The questions the customer answers when booking."
Leading note: "**Shown** puts the question on the form. **Required** means they cannot book without answering it."

One block per field: 1px border, radius 12px, overflow hidden, background `#FBF8F0`.
- Control row - CSS grid, `grid-template-columns: minmax(0,1fr) auto auto`, `align-items: center`, 10px gap, 10px/11px padding. **The two switch groups must sit at identical x-positions on every row** regardless of field-name length: each group is right-aligned with a fixed-width uppercase caption (48px for "Shown", 74px for "Required"/"Optional") beside a 40×24px switch (knob 18px, travel 16px). Shown track `#1B4332`; Required track `#B45309`; off `#DCD5C0`. Disabled: opacity .55, default cursor. The Required group dims to opacity .4 when the field is hidden.
  - Below 560px: `grid-template-columns: 1fr 1fr` with the field name spanning both columns on its own line above.
- Expansion (only when shown): 1px top border, white, 11px padding, 9px gap, containing **Wording on the form** (text input, tooltip "What the customer reads next to the box. Plain words work best.") and - for group size only - **Smallest group** / **Biggest group** number inputs side by side (each `flex: 1 1 120px`), tooltips "The fewest people you will take on one booking." and "The most people allowed on one booking. Bigger parties must ring you."

| key | Row label | Default wording | Shown | Required | Locked |
|---|---|---|---|---|---|
| `name` | Their name | Your Name | on | on | yes |
| `email` | Email address | Email | on | on | yes |
| `phone` | Phone number | Phone No. | on | off | no |
| `group_size` | How many people | Number of People | on | on | no (min 1, max 10) |
| `group_name` | Team or group name | Group Name | off | off | no |
| `special_requests` | Anything else we should know | Additional Requests | on | off | no |

Locked rows render both switches disabled and forced on - name and email are structurally required by `booking-config.ts`.

### 4. Edit sheet - category

Same sheet chrome, no tabs, two non-collapsible sections.
- **Name** - "A group name for your own lists.": Category name (required, placeholder `e.g. Games`, hint "Customers never see this.", tooltip "The group this sits in, like 'Games' or 'Music'. Customers never see this - it just keeps your lists tidy.") and Colour in your lists.
- **How it shows on the website** - "Pick the one that matches how people book.": the grouping picker, a vertical stack of the same option rows (check icon when selected, globe otherwise).

| value | Label | Blurb |
|---|---|---|
| `per_event` | Each date books separately | Every date gets its own page on the website. |
| `per_subtype` | One page per sub-category | All dates of e.g. Quiz share one page with a date picker. |
| `per_type` | One page for the whole category | All events in this category share a single page. |

Field tooltip: "How these events are shown on the website: one page each, one page per sub-category, or one page for the whole category."

---

## Interactions & behaviour

- **Breakpoint 900px** drives the pane/drill-down switch. The prototype tracks it with a resize listener; in the app prefer a CSS-only two-pane layout plus a `useMediaQuery`-gated drill state, so no layout depends on JS measuring.
- **Selecting a category** sets the selection and, on phone, enters the drilled state. Back arrow exits it. Selection highlight is only rendered in the wide sidebar.
- **Search** filters sub-categories within the selected category by name, case-insensitive, trimmed, live on keystroke. Clearing restores the full list. No debounce needed (client-side).
- **Tab navigation** in the sheet: clicking a tab jumps; the footer's primary button advances to the next tab and reads "Next: <that tab's label>". On the final tab it becomes the save action. Save is disabled whenever the short name is blank.
- **Bookable toggle** adds/removes tab 5 live. Removing the active tab falls back to tab 1.
- **Payment toggle** reveals/hides the price input.
- **Shown/Required switches**: turning Shown off dims and disables the Required switch for that field and collapses its wording/limits sub-panel. Locked fields ignore clicks.
- **Tooltips**: the "i" is a 20px round button, 1px border, `#FBF8F0`, muted glyph; hover or click opens, hover-out / outside pointerdown / Escape closes; `aria-expanded` reflects state and `aria-label` reads "What does <field> mean?". Popover: `#1F1F1A` background, `#F7F4EA` text, radius 11px, 10px/12px padding, 12.5px/1.5, `width: min(268px, 74vw)`, `box-shadow: 0 14px 34px -14px rgba(31,31,26,.6)`, 8px below the trigger, with a 10px rotated-45° caret; flips to right-aligned near the viewport edge. In the app use the shadcn `Tooltip` for hover plus `Popover` for tap, or a single `Popover` triggered by both - tap support is mandatory (the primary audience is on phones).
- **Sheet dismissal**: Escape, the close button, Cancel, or a click on the scrim itself (not on the sheet). Body scroll should be locked while open.
- **Transitions**: sheet 220ms `cubic-bezier(.2,.7,.2,1)`; switches and chevrons 180–200ms; hover colour changes 150ms.
- **Icon buttons**: 40×40px, radius 10px, transparent. Hover `#EFEADB`. Edit icons are `#B45309`; delete icons are `#DC2626` with a `#FBECEA` hover wash. Every one carries an `aria-label` ("Edit Games", "Delete Quiz", "Back to categories", "Close").
- **Delete** is unwired in the prototype - implement the codebase's existing confirm-then-`deleteEventType` flow.
- **Minimum touch target 40px**; primary/lg buttons and inputs are 44px.

## State management

Client state only; all persistence goes through the existing server actions.

- `selectedCategoryId` - which category the right pane shows.
- `isDrilled` - phone-only; whether the detail pane replaces the list.
- `query` - the sub-category search string.
- `editing` - `null`, or `{ kind: "cat" | "sub", isNew?: boolean, cat, ...record }`. Opening a sheet copies the record into local draft state; Cancel discards it, Save submits.
- `activeTab` - sheet tab id, reset to `basics` on open.
- `draft.fields` - the booking-config map, seeded from `BOOKING_FIELD_DEFAULTS` when absent, patched per field.

Data: keep the existing server-component fetch of categories with nested sub-categories, and the existing `createEventType` / `updateEventType` / `deleteEventType` (and category equivalents) actions. Nothing here needs a new endpoint. Booking-config values persist in the same JSON column `booking-config.ts` already reads.

## Design tokens

Admin (cream/espresso) surface - matches `globals.css`.

| Token | Value | Use |
|---|---|---|
| Desk backdrop | `#E9E3D2` | outside the app frame |
| Canvas | `#F7F4EA` | page + sheet background |
| Card | `#FFFDF7` | cards, bars, sheet head/foot |
| Inset | `#FBF8F0` | section headers, option rows, chips |
| Border | `#E6DFC8` | all 1px borders |
| Border soft | `#EFEADB` | internal dividers; hover wash |
| Ink | `#1F1F1A` | body text, tooltip background |
| Muted | `#5F624F` | secondary text |
| Espresso | `#5C4033` | selected state, focus ring |
| **Base green** | `#1B4332` | primary buttons, "on" switches |
| Green hover | `#173A2B` | primary hover |
| Green wash / border | `#EAF1EC` / `#C3D8CC` | positive rows and chips |
| Amber | `#B45309` | edit icons, Required switch |
| Red | `#DC2626` | delete icons |
| Red text / wash | `#B4453C` / `#FBECEA` | error text, delete hover |
| Switch off | `#DCD5C0` | - |

Radii: 8px chips · 9–10px buttons and icon buttons · 11px tooltip and icon cells · 12px option/toggle rows and search · 14px cards · 20px sheet · 99px pills and switches.

Spacing: 2 · 4 · 6 · 8 · 10 · 12 · 14 · 18 · 22 · 26px.

Type - **Archivo** for body/UI, **Archivo Black** for headings and emphasis:
| Role | Size / weight |
|---|---|
| H1 | 24px (20px phone), Archivo Black, -.01em |
| Sheet title | 18px Archivo Black |
| Card title | 15.5–16px Archivo Black |
| Section title | 13px Archivo Black, uppercase, .1em |
| Body / input | 14.5–15px |
| Secondary | 12.5–13.5px, muted |
| Hint | 12px, muted, 1.5 |
| Eyebrow / caption | 10.5–11.5px, weight 700, uppercase, .16em |

Shadows: only two - tooltip `0 14px 34px -14px rgba(31,31,26,.6)` and switch knob `0 1px 3px rgba(0,0,0,.2)`. Focus ring: `border-color: #5C4033` + `box-shadow: 0 0 0 3px rgba(92,64,51,.12)`.

### Sub-category colour palette
Twelve named colours, each with `bg` / `text` / `border` / `solid`, taken from `event-type-colors.ts`: amber, green, purple, blue, rose, sky, orange, teal, indigo, pink, emerald, violet. `solid` is the list dot; `bg`+`text` fill the card's icon tile. Swatches render as 30px circles, 2px border; selected gets an ink border, a white 2px inset outline, and a white check.

### Fact chips
Derived, read-only summary chips on each sub-category card, in this order: behaviour label · "Books online" (green variant) or "Not online" · "Needs a host" (if set) · "Table seating" (if set) · price - "£5 per person" or "Free entry". Chip: 1px border `#EFEADB`, background `#FBF8F0`, radius 8px, 4px/8px padding, 11.5px weight 600, 13px leading icon. Green variant: `#EAF1EC` / `#C3D8CC` / `#1B4332`.

### Icon mapping (prototype → lucide-react)
sparkles→Sparkles · trophy→Trophy · disc→Disc3 · mic→Mic · music→Music · users→Users · user→User · globe→Globe · eyeoff→EyeOff · chair→Armchair · ticket→Ticket · pound→PoundSterling · cal→Calendar · clock→Clock · pin→MapPin · note→StickyNote · star→Star · check→Check · image→Image · layers→Layers · pencil→Pencil · trash→Trash2 · plus→Plus · search→Search · x→X · chevron→ChevronDown · arrowLeft→ArrowLeft. All 24×24, 1.9px stroke, round caps/joins.

## Prototype → codebase mapping

| Prototype | Use in bar-app |
|---|---|
| `Sheet` / `.scrim` / `.sheet` | shadcn `Sheet` (`side="bottom"`) or `Dialog`, keeping the centred-bottom geometry above |
| `.tabs` | shadcn `Tabs` with `TabsList` allowed to wrap |
| `ToggleWithTip`, `MiniSw` | shadcn `Switch` + `Label`, colours per the token table |
| `InfoTip` | shadcn `Tooltip` + `Popover` (tap must work) |
| `TextIn` / `AreaIn` | `Input` / `Textarea` from the DS |
| `Btn` | DS `Button` - `variant="default"` overridden to `#1B4332`, `variant="secondary"` for Cancel, `variant="ghost"` for icon buttons |
| `Section` | `Card` + `CardHeader`/`CardContent` |
| `Field` | `FormItem`/`FormLabel`/`FormDescription`/`FormMessage` - the hint is the description, the error the message |
| inline `style` objects | Tailwind utilities against existing tokens |
| `Ic` icon set | `lucide-react` per the mapping table |
| `DATA` | the real server-fetched categories |

## Copy rules

The wording is deliberate and part of the design. Preserve it.
- Never expose internal vocabulary: no "behaviour", "grouping", "per_subtype", "visible", "boolean". Say "kind of night", "booking pages", "shown".
- Questions, not nouns, for switches: "Can customers book it online?" not "Bookable".
- State what the user will experience: "You'll be asked who is hosting each date."
- Every field: one short always-visible hint plus a longer plain-English tooltip. Tooltip copy assumes the reader does not use websites.
- Buttons say what they do - "Add a night to Games", not "Add".
- Currency symbol is £ and shown once; free entry uses the "Free entry" chip, never "£0".

## Assets

None. All iconography becomes `lucide-react`. Fonts are Archivo + Archivo Black (already in the app). Image dropzones are placeholders for the existing upload flow. The sample content in the prototype (Games/Music/Party/Private hire/Sports and their nights) is illustrative only.

## Screenshots

`screenshots/` - reference captures of the prototype. Every measurement in this README is authoritative; the images are for orientation.

| File | Shows |
|---|---|
| `01-explorer-wide.png` | the two-pane explorer at desktop width |
| `02-edit-sheet-tab1-name.png` | edit sheet, tab 1 (Name) |
| `03-edit-sheet-tab2-kind-of-night.png` | tab 2, the behaviour picker |
| `04-edit-sheet-tab3-what-it-needs.png` | tab 3, the four question toggles |
| `05-edit-sheet-tab4-website.png` | tab 4, tagline / poster / badges / preview |
| `06-edit-sheet-tab5-booking-card.png` | tab 5, Booking card section |
| `07-edit-sheet-tab5-form-fields.png` | tab 5, Form fields with the Shown / Required columns |
| `08-phone-category-list.png` | phone, category list with the bottom action bar |
| `09-phone-inside-category.png` | phone, inside a category - sticky header + contextual bottom bar |
| `10-phone-edit-sheet.png` | phone, the edit sheet |

## Files in this bundle

| File | What it is |
|---|---|
| `Event Categories Option B.html` | the design reference - open in a browser to interact with it |
| `ec-option-b.jsx` | explorer + edit sheet + booking tab |
| `ec-shared.jsx` | icons, colours, behaviour/grouping lists, tooltip and hint copy, shared form parts, sample data |
| `ec.css` | tokens and layout |
| `Option B on mobile.html` | three phone states side by side |
| `_ds/` | the bound Don Fenticas design-system bundle the prototype loads |

Open the HTML from a static server (or double-click it) - it needs no build step. Note the prototype has no persistence: sheet edits are discarded on close.
