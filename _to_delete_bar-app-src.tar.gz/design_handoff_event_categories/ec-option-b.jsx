/* Option B — "Two-pane explorer", refined.
   Wide: sticky category sidebar + two-column cards, editing in a right-hand slide-in panel.
   Phone: one pane, drill down with a sticky category header and a fixed bottom action bar. */
const { useState: useStateB, useEffect: useEffectB } = React;

function useNarrow() {
  const [n, setN] = useStateB(() => window.innerWidth < 900);
  useEffectB(() => {
    const on = () => setN(window.innerWidth < 900);
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);
  return n;
}

function CatItem({ c, active, onClick }) {
  const cc = col(c.colour);
  return (
    <button type="button" onClick={onClick} aria-current={active}
      style={{ display: "flex", alignItems: "center", gap: 11, width: "100%", padding: "12px 13px", border: "1px solid " + (active ? "var(--espresso)" : "transparent"),
        background: active ? "#F1E9E2" : "transparent", borderRadius: 12, textAlign: "left" }}>
      <span style={{ width: 10, height: 10, borderRadius: 99, background: cc.solid, flex: "none" }} />
      <span style={{ flex: 1, minWidth: 0 }}>
        <span className="blk" style={{ display: "block", fontSize: 14 }}>{c.name}</span>
        <span style={{ display: "block", fontSize: 12, color: "var(--muted)", marginTop: 1 }}>{c.subs.length} sub-{c.subs.length === 1 ? "category" : "categories"}</span>
      </span>
      <Ic n="chevron" s={15} style={{ color: "var(--muted)", transform: "rotate(-90deg)" }} />
    </button>
  );
}

function SubCard({ s, onEdit }) {
  const c = col(s.colour);
  return (
    <div className="card" style={{ padding: 14, display: "flex", flexDirection: "column", gap: 11 }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 11 }}>
        <span style={{ width: 38, height: 38, borderRadius: 10, background: c.bg, color: c.text, display: "grid", placeItems: "center", flex: "none" }}>
          <Ic n={bh(s.behaviour).icon} s={18} />
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p className="blk" style={{ margin: 0, fontSize: 15.5 }}>{s.name}</p>
          <p style={{ margin: "3px 0 0", fontSize: 12.5, color: "var(--muted)", lineHeight: 1.45 }}>
            {s.title ? <>Website name <b style={{ color: "var(--ink)", fontWeight: 700 }}>{s.title}</b></> : "No website name set — the short name is used"}
          </p>
        </div>
        <div className="row-actions">
          <button type="button" className="btn btn-quiet btn-sm" style={{ color: "#B45309" }} onClick={() => onEdit(s)}><Ic n="pencil" s={13} />Edit</button>
          <button type="button" className="iconbtn danger" style={{ color: "#DC2626" }} aria-label={`Delete ${s.name}`}><Ic n="trash" s={15} /></button>
        </div>
      </div>
      <Facts s={s} />
      {s.badges.length > 0 && (
        <div style={{ background: "#EAF1EC", border: "1px solid #C3D8CC", borderRadius: 11, padding: "9px 10px", display: "flex", flexDirection: "column", gap: 7 }}>
          <p className="eyebrow" style={{ display: "flex", alignItems: "center", gap: 6, color: "#1B4332" }}>
            <Ic n="globe" s={12} />Shown on the booking page
          </p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {s.badges.map((b, i) => <span className="tag" key={i} style={{ background: "#FFFDF7", borderColor: "#C3D8CC" }}><Ic n={b.icon} s={13} /><b style={{ color: "var(--ink)" }}>{b.title}</b>{b.desc && <span>· {b.desc}</span>}</span>)}
          </div>
        </div>
      )}
    </div>
  );
}

function OptionB() {
  const narrow = useNarrow();
  const [sel, setSel] = useStateB(DATA[0].id);
  const [drilled, setDrilled] = useStateB(window.EC_VIEW === "detail" || window.EC_VIEW === "edit");
  const [q, setQ] = useStateB("");
  const [form, setForm] = useStateB(window.EC_VIEW === "edit" ? { kind: "sub", cat: DATA[0], ...DATA[0].subs[0] } : null);
  const cat = DATA.find(c => c.id === sel) || DATA[0];
  const subs = cat.subs.filter(s => !q.trim() || s.name.toLowerCase().includes(q.trim().toLowerCase()));
  const showList = !narrow || !drilled;
  const showDetail = !narrow || drilled;
  const newSub = () => setForm({ kind: "sub", isNew: true, cat, name: "", colour: "sky", behaviour: "standard", badges: [], seating: true });
  const newCat = () => setForm({ kind: "cat", isNew: true, name: "", colour: "amber", grouping: "per_event" });

  return (
    <>
      {narrow && drilled && (
        <div className="mhead">
          <button type="button" className="iconbtn" aria-label="Back to categories" onClick={() => setDrilled(false)}><Ic n="arrowLeft" s={18} /></button>
          <span style={{ width: 10, height: 10, borderRadius: 99, background: col(cat.colour).solid, flex: "none" }} />
          <h2 className="blk">{cat.name}</h2>
          <button type="button" className="iconbtn" style={{ color: "#B45309" }} aria-label={`Edit ${cat.name}`} onClick={() => setForm({ kind: "cat", ...cat })}><Ic n="pencil" s={16} /></button>
        </div>
      )}

      <div className="wrap" style={{ paddingBottom: narrow ? 88 : undefined }}>
        {showList && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 14, alignItems: "flex-end", justifyContent: "space-between", marginBottom: 18 }}>
            <div>
              <p className="sub" style={{ marginTop: 0 }}>{narrow ? "Tap a category to see the nights inside it." : "Pick a category on the left to see the nights inside it."}</p>
            </div>
            {!narrow && <Btn className="ec-green" size="lg" onClick={newCat}><Ic n="plus" s={15} />New category</Btn>}
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: narrow ? "1fr" : "clamp(230px,25%,290px) 1fr", gap: 18, alignItems: "start" }}>
          {showList && (
            <div className="card" style={{ padding: 8, position: narrow ? "static" : "sticky", top: 16 }}>
              {!narrow && <p className="eyebrow" style={{ padding: "8px 6px 6px" }}>Categories</p>}
              <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                {DATA.map(c => <CatItem key={c.id} c={c} active={!narrow && c.id === cat.id} onClick={() => { setSel(c.id); setDrilled(true); }} />)}
              </div>
              {!narrow && (
                <button type="button" className="btn btn-ghost btn-sm" style={{ margin: "6px 0 2px", width: "100%" }} onClick={newCat}>
                  <Ic n="plus" s={13} />Add a category
                </button>
              )}
            </div>
          )}

          {showDetail && (
            <div style={{ display: "flex", flexDirection: "column", gap: 14, minWidth: 0 }}>
              <div className="card" style={{ padding: 14, display: "flex", flexDirection: "column", gap: 12 }}>
                {!narrow && (
                  <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                    <span style={{ width: 12, height: 12, borderRadius: 99, background: col(cat.colour).solid, flex: "none" }} />
                    <h2 className="blk" style={{ margin: 0, fontSize: 18, flex: 1, minWidth: 0 }}>{cat.name}</h2>
                    <button type="button" className="iconbtn" style={{ color: "#B45309" }} aria-label={`Edit ${cat.name}`} onClick={() => setForm({ kind: "cat", ...cat })}><Ic n="pencil" s={15} /></button>
                    <button type="button" className="iconbtn danger" style={{ color: "#DC2626" }} aria-label={`Delete ${cat.name}`}><Ic n="trash" s={15} /></button>
                  </div>
                )}
                <p style={{ margin: 0, fontSize: 13, color: "var(--muted)", lineHeight: 1.5 }}>
                  <b style={{ color: "var(--ink)" }}>On the website:</b> {GROUPING.find(g => g.value === cat.grouping).blurb}
                </p>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                  <div className="searchbar" style={{ flex: "1 1 200px" }}>
                    <Ic n="search" s={16} style={{ color: "var(--muted)", flex: "none" }} />
                    <input value={q} onChange={e => setQ(e.target.value)} placeholder={`Search in ${cat.name}`} aria-label={`Search in ${cat.name}`} />
                  </div>
                  {!narrow && <Btn className="ec-sub" onClick={newSub}><Ic n="plus" s={14} />Sub-Category</Btn>}
                </div>
              </div>

              {subs.length === 0
                ? <div className="card empty"><Ic n="layers" s={22} /><p className="blk" style={{ margin: "8px 0 2px", fontSize: 14 }}>Nothing in here yet</p><p style={{ margin: 0, fontSize: 12.5 }}>Add a sub-category to get started.</p></div>
                : <div style={{ display: "grid", gridTemplateColumns: narrow ? "1fr" : "repeat(auto-fill,minmax(min(100%,340px),1fr))", gap: 12 }}>
                    {subs.map(s => <SubCard key={s.id} s={s} onEdit={sub => setForm({ kind: "sub", cat, ...sub })} />)}
                  </div>}
            </div>
          )}
        </div>
      </div>

      {narrow && (
        <div className="mbar">
          {drilled
            ? <Btn className="ec-sub" size="lg" onClick={newSub}><Ic n="plus" s={15} />Sub-Category in {cat.name}</Btn>
            : <Btn className="ec-green" size="lg" onClick={newCat}><Ic n="plus" s={15} />New category</Btn>}
        </div>
      )}

      {form && form.kind === "sub" && <SubSheetB form={form} setForm={setForm} onClose={() => setForm(null)} />}
      {form && form.kind === "cat" && <CatSheetB form={form} setForm={setForm} onClose={() => setForm(null)} />}
    </>
  );
}

const TABS_ALL = [
  { id: "basics", label: "Name" },
  { id: "kind", label: "Kind of night" },
  { id: "needs", label: "What it needs" },
  { id: "web", label: "Website" },
  { id: "booking", label: "Booking form" },
];
const BOOK_FIELDS = [
  { key: "name", label: "Their name", def: "Your Name", locked: true },
  { key: "email", label: "Email address", def: "Email", locked: true },
  { key: "phone", label: "Phone number", def: "Phone No." },
  { key: "group_size", label: "How many people", def: "Number of People", size: true },
  { key: "group_name", label: "Team or group name", def: "Group Name" },
  { key: "special_requests", label: "Anything else we should know", def: "Additional Requests" },
];
const BOOK_DEFAULTS = {
  name: { visible: true, required: true, label: "Your Name" },
  email: { visible: true, required: true, label: "Email" },
  phone: { visible: true, required: false, label: "Phone No." },
  group_size: { visible: true, required: true, label: "Number of People", min: 1, max: 10 },
  group_name: { visible: false, required: false, label: "Group Name" },
  special_requests: { visible: true, required: false, label: "Additional Requests" },
};
const CARD_ICONS = ["cal", "pin", "clock", "note", "users", "star", "check", "music", "trophy", "disc", "mic", "ticket", "globe", "sparkles"];

function MiniSw({ on, onClick, label, tone, disabled }) {
  return (
    <button type="button" aria-label={label} aria-pressed={!!on} disabled={disabled} onClick={onClick}
      style={{ position: "relative", width: 40, height: 24, borderRadius: 99, border: 0, padding: 0, flex: "none",
        background: on ? (tone === "req" ? "#B45309" : "#1B4332") : "#DCD5C0", opacity: disabled ? .55 : 1, cursor: disabled ? "default" : "pointer" }}>
      <span style={{ position: "absolute", top: 3, left: 3, width: 18, height: 18, borderRadius: 99, background: "#fff",
        boxShadow: "0 1px 3px rgba(0,0,0,.2)", transform: on ? "translateX(16px)" : "none", transition: "transform .18s" }} />
    </button>
  );
}

function SubSheetB({ form, setForm, onClose }) {
  const [tab, setTab] = useStateB("basics");
  const set = patch => setForm({ ...form, ...patch });
  const fields = form.fields || BOOK_DEFAULTS;
  const setField = (k, patch) => set({ fields: { ...fields, [k]: { ...fields[k], ...patch } } });
  const nameErr = !form.name.trim() ? "Give it a short name so your team can find it." : null;
  const TABS_B = TABS_ALL.filter(t => t.id !== "booking" || form.bookable);
  const iRaw = TABS_B.findIndex(t => t.id === tab);
  const i = iRaw === -1 ? 0 : iRaw;
  const cur = TABS_B[i].id;
  const last = i === TABS_B.length - 1;
  return (
    <Sheet open onClose={onClose} side>
      <SheetHead eyebrow={`Sub-category in ${form.cat?.name || ""}`} title={form.isNew ? "New sub-category" : form.name || "Sub-category"} onClose={onClose} />
      <div className="tabs" role="tablist">
        {TABS_B.map((t, k) => (
          <button key={t.id} role="tab" aria-selected={cur === t.id} onClick={() => setTab(t.id)}>
            <span style={{ opacity: .55, marginRight: 5 }}>{k + 1}</span>{t.label}
          </button>
        ))}
      </div>
      <div className="sheet-body">
        {cur === "basics" && (
          <Section title="Name" blurb="What you call it, and what customers read." collapsible={false}>
            <Field label="Short name" help={HELP.name} hint={HINT.name} required error={nameErr}>
              <TextIn value={form.name} placeholder="e.g. Quiz" onChange={e => set({ name: e.target.value })} />
            </Field>
            <Field label="Name on the website" help={HELP.title} hint={HINT.title}>
              <TextIn value={form.title || ""} placeholder="e.g. Quiz Night" onChange={e => set({ title: e.target.value })} />
            </Field>
            <Field label="Fills in new events as" help={HELP.defaultTitle} hint={HINT.defaultTitle}>
              <TextIn value={form.defaultTitle || ""} placeholder="e.g. Thursday Quiz Night" onChange={e => set({ defaultTitle: e.target.value })} />
            </Field>
            <Field label="Colour in your lists" help={HELP.colour} hint={HINT.colour}>
              <Swatches value={form.colour} onChange={v => set({ colour: v })} />
            </Field>
          </Section>
        )}
        {cur === "kind" && (
          <Section title="Kind of night" blurb="This switches on the right tools." collapsible={false}>
            <Field label="Kind of night" help={HELP.behaviour} hint={HINT.behaviour}>
              <BehaviourPicker value={form.behaviour} onChange={v => set({ behaviour: v })} />
            </Field>
          </Section>
        )}
        {cur === "needs" && (
          <Section title="What it needs" blurb="Set once — every date of this kind follows." collapsible={false}>
            <ToggleWithTip label="Can customers book it online?" help={HELP.bookable} value={!!form.bookable} onChange={v => set({ bookable: v })}
              sub={{ on: "Yes — bookable on the website", off: "No — phone or walk-in only", onHint: "A booking page is created for it.", offHint: "You can still add bookings by hand." }} />
            <ToggleWithTip label="Does someone have to run it?" help={HELP.host} value={!!form.host} onChange={v => set({ host: v })}
              sub={{ on: "Yes — a host is needed", off: "No host needed", onHint: "You'll be asked who is hosting each date." }} />
            <ToggleWithTip label="Are guests given tables?" help={HELP.seating} value={!!form.seating} onChange={v => set({ seating: v })}
              sub={{ on: "Yes — seated", off: "No — standing", onHint: "Tables are allocated when people book." }} />
            <ToggleWithTip label="Do people pay to book?" help={HELP.payment} value={!!form.payment} onChange={v => set({ payment: v })} sub={{ on: "Yes — paid entry", off: "Free to book" }} />
            {form.payment && <Field label="Price per person (£)" help={HELP.price} hint={HINT.price}><TextIn type="number" value={form.price || ""} placeholder="5.00" onChange={e => set({ price: e.target.value })} /></Field>}
          </Section>
        )}
        {cur === "web" && (
          <>
            <Section title="What customers see" blurb="Words, picture and badges on the booking page." collapsible={false}>
              <Field label="One line to sell it" help={HELP.tagline} hint={HINT.tagline}>
                <AreaIn value={form.tagline || ""} placeholder="Six rounds, one winner, plenty of arguing." onChange={e => set({ tagline: e.target.value })} />
              </Field>
              <Field label="Poster picture" help={HELP.image} hint={HINT.image}>
                <button type="button" className="dropzone">
                  <Ic n="image" s={22} />
                  <span className="blk" style={{ fontSize: 12.5, letterSpacing: ".08em", textTransform: "uppercase" }}>Choose a picture</span>
                  <span style={{ fontSize: 11.5, textAlign: "center" }}>Used when an event has no picture of its own</span>
                </button>
              </Field>
              <Field label="Badges" help={HELP.badges} hint={HINT.badges}>
                <BadgeList badges={form.badges || []} onAdd={() => set({ badges: [...(form.badges || []), { icon: "star", title: "New badge", desc: "" }] })}
                  onRemove={k => set({ badges: form.badges.filter((_, j) => j !== k) })} />
              </Field>
            </Section>
            <div className="previewbox">
              <p className="eyebrow">How it will look</p>
              <p className="blk" style={{ margin: 0, fontSize: 16 }}>{form.title || form.name || "Your night"}</p>
              {form.tagline && <p style={{ margin: 0, fontSize: 13, color: "var(--muted)" }}>{form.tagline}</p>}
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {(form.badges || []).map((b, k) => <span className="tag" key={k}><Ic n={b.icon} s={13} /><b style={{ color: "var(--ink)" }}>{b.title}</b></span>)}
              </div>
            </div>
          </>
        )}
        {cur === "booking" && (
          <>
            <Section title="Booking card" blurb="The tile customers tap on the booking page." collapsible={false}>
              <p className="hint">Leave a box blank and it falls back to the website name, a calendar icon and the automatic label.</p>
              <Field label="Card title" help="The heading on the tile customers tap. Leave blank to use the website name." hint="Blank = the website name.">
                <TextIn value={form.booking_card_title || ""} placeholder={form.title || form.name} onChange={e => set({ booking_card_title: e.target.value })} />
              </Field>
              <Field label="Card tagline" help="A sentence or two on the tile telling people what the night is." hint="One or two sentences.">
                <AreaIn value={form.booking_card_tagline || ""} placeholder="Book a table for our weekly quiz night. Eight rounds, great prizes, and happy hour vibes." onChange={e => set({ booking_card_tagline: e.target.value })} />
              </Field>
              <Field label="Card note" help="A short word or two in the corner of the tile, like “Thursdays” or “Popular”. Leave blank for none." hint="Optional, e.g. “Thursdays”.">
                <TextIn value={form.booking_card_badge || ""} placeholder="Thursdays" onChange={e => set({ booking_card_badge: e.target.value })} />
              </Field>
              <Field label="Card icon" help="The little picture on the tile. Pick whatever looks closest to the night.">
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(52px,1fr))", gap: 8 }}>
                  {CARD_ICONS.map(ic => (
                    <button key={ic} type="button" aria-label={ic} aria-pressed={form.booking_card_icon === ic} onClick={() => set({ booking_card_icon: ic })}
                      style={{ height: 48, borderRadius: 11, display: "grid", placeItems: "center",
                        border: "1.5px solid " + (form.booking_card_icon === ic ? "#1B4332" : "var(--line)"),
                        background: form.booking_card_icon === ic ? "#EAF1EC" : "#fff",
                        color: form.booking_card_icon === ic ? "#1B4332" : "var(--muted)" }}>
                      <Ic n={ic} s={18} />
                    </button>
                  ))}
                </div>
              </Field>
            </Section>

            <Section title="Booking page" blurb="The page people land on after tapping the card." collapsible={false}>
              <Field label="Booking image (logo)" help="A logo or poster shown at the top of the booking page — handy for a sponsor." hint="Optional. Shown across the top of the page.">
                <button type="button" className="dropzone">
                  <Ic n="image" s={22} />
                  <span className="blk" style={{ fontSize: 12.5, letterSpacing: ".08em", textTransform: "uppercase" }}>Choose a picture</span>
                  <span style={{ fontSize: 11.5, textAlign: "center" }}>JPG or PNG from your phone or computer</span>
                </button>
              </Field>
              <Field label="Tagline" help="One line under the logo on the booking page." hint="Shown under the logo.">
                <TextIn value={form.booking_page_tagline || ""} placeholder="Description shown under the logo" onChange={e => set({ booking_page_tagline: e.target.value })} />
              </Field>
            </Section>

            <Section title="Form fields" blurb="The questions the customer answers when booking." collapsible={false}>
              <p className="hint"><b>Shown</b> puts the question on the form. <b>Required</b> means they cannot book without answering it.</p>
              {BOOK_FIELDS.map(fd => {
                const v = fields[fd.key] || {};
                const shown = fd.locked ? true : !!v.visible;
                return (
                  <div key={fd.key} style={{ border: "1px solid var(--line)", borderRadius: 12, overflow: "hidden", background: "#FBF8F0" }}>
                    <div className="ffrow">
                      <b style={{ fontSize: 13, minWidth: 0 }}>{fd.label}</b>
                      <span className="sws short">
                        <em style={{ color: shown ? "#1B4332" : "var(--muted)" }}>Shown</em>
                        <MiniSw on={shown} disabled={fd.locked} label={`Show ${fd.label}`} onClick={() => setField(fd.key, { visible: !v.visible })} />
                      </span>
                      <span className="sws" style={{ opacity: shown ? 1 : .4 }}>
                        <em style={{ color: v.required ? "#B45309" : "var(--muted)" }}>{v.required ? "Required" : "Optional"}</em>
                        <MiniSw on={!!v.required} tone="req" disabled={fd.locked || !shown} label={`Make ${fd.label} required`} onClick={() => setField(fd.key, { required: !v.required })} />
                      </span>
                    </div>
                    {shown && (
                      <div style={{ borderTop: "1px solid var(--line)", background: "#fff", padding: 11, display: "flex", flexDirection: "column", gap: 9 }}>
                        <Field label="Wording on the form" help="What the customer reads next to the box. Plain words work best.">
                          <TextIn value={v.label ?? fd.def} aria-label={`Wording for ${fd.label}`} onChange={e => setField(fd.key, { label: e.target.value })} />
                        </Field>
                        {fd.size && (
                          <div style={{ display: "flex", gap: 9, flexWrap: "wrap" }}>
                            <span style={{ flex: "1 1 120px" }}>
                              <Field label="Smallest group" help="The fewest people you will take on one booking.">
                                <TextIn type="number" value={v.min ?? 1} onChange={e => setField(fd.key, { min: e.target.value })} />
                              </Field>
                            </span>
                            <span style={{ flex: "1 1 120px" }}>
                              <Field label="Biggest group" help="The most people allowed on one booking. Bigger parties must ring you.">
                                <TextIn type="number" value={v.max ?? 10} onChange={e => setField(fd.key, { max: e.target.value })} />
                              </Field>
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </Section>
          </>
        )}
      </div>
      <div className="sheet-foot">
        <Btn variant="secondary" size="lg" onClick={onClose}>Cancel</Btn>
        {!last
          ? <Btn size="lg" disabled={!!nameErr} onClick={() => setTab(TABS_B[i + 1].id)}>Next: {TABS_B[i + 1].label}</Btn>
          : <Btn size="lg" disabled={!!nameErr} onClick={onClose}>{form.isNew ? "Create" : "Save changes"}</Btn>}
      </div>
    </Sheet>
  );
}

function CatSheetB({ form, setForm, onClose }) {
  const set = patch => setForm({ ...form, ...patch });
  return (
    <Sheet open onClose={onClose} side>
      <SheetHead eyebrow="Category" title={form.isNew ? "New category" : form.name} onClose={onClose} />
      <div className="sheet-body">
        <Section title="Name" blurb="A group name for your own lists." collapsible={false}>
          <Field label="Category name" help={HELP.catName} hint="Customers never see this." required>
            <TextIn value={form.name} placeholder="e.g. Games" onChange={e => set({ name: e.target.value })} />
          </Field>
          <Field label="Colour in your lists" help={HELP.colour} hint={HINT.colour}>
            <Swatches value={form.colour} onChange={v => set({ colour: v })} />
          </Field>
        </Section>
        <Section title="How it shows on the website" blurb="Pick the one that matches how people book." collapsible={false}>
          <Field label="Booking pages" help={HELP.grouping} hint={HINT.grouping}>
            <GroupingPicker value={form.grouping} onChange={v => set({ grouping: v })} />
          </Field>
        </Section>
      </div>
      <div className="sheet-foot">
        <Btn variant="secondary" size="lg" onClick={onClose}>Cancel</Btn>
        <Btn size="lg" onClick={onClose}>{form.isNew ? "Create" : "Save changes"}</Btn>
      </div>
    </Sheet>
  );
}

Object.assign(window, { OptionB, SubSheetB, CatSheetB, SubCard, CatItem });
