# Don Fenticas (bar-app) — design-system POC

A **proof-of-concept** import of two primitives (`Button`, `Input`) from the
`bar-app` Next.js app. Read this before composing UI with them.

## The token layer (admin espresso/cream)

These shadcn-derived primitives reference semantic colour utilities — `bg-primary`,
`text-primary-foreground`, `bg-secondary`, `bg-destructive`, `bg-accent`,
`border-input`, `ring-ring`. The app's `globals.css` now defines the backing theme
variables in a `:root` block, re-exported through `@theme inline` as `--color-*`,
so **these utilities resolve to real colour** and `Button` variants render with fill.

The token values are the **admin-portal** palette (the working-tool surface), *not*
the public marketing palette:

| Token | Value | Meaning |
|---|---|---|
| `--primary` / `--ring` | `#5C4033` | espresso |
| `--primary-foreground` / `--background` / `--accent` | `#F7F4EA` | cream |
| `--secondary` / `--border` / `--input` | `#E6DFC8` | soft tan border |
| `--destructive` | `#DC2626` | status red |
| `--foreground` | `#1F1F1A` | near-black ink |

So out of the box `Button` looks like an **admin** button: espresso fill, cream text.

## Two surfaces — pick the colour strategy per surface

bar-app has two intentionally-separate surfaces:

- **Admin portal** — cream canvas `#F7F4EA`, espresso primary `#5C4033`. Here the
  `variant` props match the surface: use `Button` / `Button variant="secondary"` /
  `variant="destructive"` as-is; they already carry the right colours.
- **Public site** ("gritty bar") — deep olive `#26300D`/`#14180a`, gold accent
  `#FDCC4B`. The token layer is admin-only, so on this surface **override colour with
  explicit classes** rather than relying on `variant` — e.g.
  `className="bg-[#FDCC4B] text-[#26300D] hover:bg-[#FDCC4B]/90"`.

Never mix the two palettes on one surface.

## Components

- **`Button`** — `variant`: `default | destructive | outline | secondary | ghost |
  link`; `size`: `default | xs | sm | lg | icon | icon-xs | icon-sm | icon-lg`;
  `asChild`; plus the native `<button>` attributes declared in `Button.d.ts`
  (`type`, `disabled`, `onClick`, `name`, `value`, `form`, `title`, `aria-label`,
  `tabIndex`). Both axes render fully (sizing **and** colour).
- **`Input`** — the native `<input>` attributes declared in `Input.d.ts`: `type`,
  `placeholder`, `value`/`defaultValue`, `onChange`/`onBlur`/`onFocus`, `disabled`,
  `readOnly`, `required`, `name`, `autoComplete`, `min`/`max`/`step`, `maxLength`,
  `pattern`, `inputMode`, `aria-label`. A bordered, rounded field with a focus
  ring. Safe to use as-is on either surface.

Both spread any further props straight onto the underlying DOM element, so an
attribute missing from the `.d.ts` still works at runtime — but prefer the
declared ones; they are the contract.

## Build snippets

Admin surface — variants supply the colour:

```tsx
import { Button, Input } from "bar-app-ds";

<form className="flex flex-col gap-3">
  <Input placeholder="Customer name" />
  <Button>Save booking</Button>
  <Button variant="secondary">Cancel</Button>
</form>
```

Public surface — override colour to gold-on-olive:

```tsx
<Button className="bg-[#FDCC4B] text-[#26300D] hover:bg-[#FDCC4B]/90">
  Book now
</Button>
```

# BarApp (bar-app-ds@0.1.0)

This design system is the published bar-app-ds React library, bundled as a single
browser global. All 2 components are the real upstream code.

## Where things are

- `_ds_bundle.js` — the whole-DS bundle at the project root; loads every component to `window.BarApp`. First line is a `/* @ds-bundle: … */` metadata header.
- `styles.css` — the single stylesheet entry: it `@import`s the tokens, fonts, and component styles (`_ds_bundle.css`). Link this one file.
- `components/<group>/<Name>/<Name>.prompt.md` (example JSX + variants), `<Name>.d.ts` (types), `<Name>.html` (variant grid).
- `tokens/*.css` — CSS custom properties, names verbatim from upstream.
- `fonts/` — `@font-face` files + `fonts.css` (when the package ships fonts).

For a specific component, `read_file("components/<group>/<Name>/<Name>.prompt.md")`.

## Loading

Add these two lines to your page once (React must be on the page first):

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
```

Components are then available at `window.BarApp.*`. Mount into a dedicated child node (e.g. `<div id="ds-root">`), not the host page's own React root, so the two trees don't collide:

```jsx
const { Button } = window.BarApp;
ReactDOM.createRoot(document.getElementById('ds-root')).render(<Button />);
```

## Tokens

333 CSS custom properties from bar-app-ds. Names are
preserved verbatim from upstream. They are declared inside `_ds_bundle.css` (this DS ships one compiled stylesheet rather than separate token files).

- **color** (166): `--color-red-50`, `--color-red-100`, `--color-red-200`, …
- **spacing** (6): `--tw-space-y-reverse`, `--tw-ring-inset`, `--tw-space-x-reverse`, …
- **typography** (21): `--font-sans`, `--font-serif`, `--font-mono`, …
- **radius** (8): `--radius-xs`, `--radius-sm`, `--radius-md`, …
- **shadow** (7): `--tw-shadow`, `--tw-ring-shadow`, `--tw-ring-offset-shadow`, …
- **other** (125): `--spacing`, `--container-xs`, `--container-sm`, …

## Components

### general
- `Button`
- `Input`
