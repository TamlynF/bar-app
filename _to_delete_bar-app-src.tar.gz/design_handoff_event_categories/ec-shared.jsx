/* Shared data, icons, tooltips and form parts for the Event Categories redesign */
const { useState, useEffect, useRef } = React;

const P = {
  plus:"M12 5v14M5 12h14", pencil:"M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z",
  trash:"M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14", chevron:"M6 9l6 6 6-6",
  search:"M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM21 21l-4.35-4.35",
  x:"M6 6l12 12M18 6L6 18", check:"M5 13l4 4L19 7",
  user:"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8",
  ticket:"M3 9V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a2 2 0 0 0 0 6v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-6M13 5v14",
  chair:"M6 19v-4h12v4M7 15V5h10v10M4 19h16",
  note:"M2 6h20v12H2zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6M5 9.5h.01M19 14.5h.01",
  pound:"M8 13h6M9 20h9M9 20c1.5-1.5 2-3 2-5V9a3 3 0 0 1 6 0",
  image:"M3 5h18v14H3zM3 15l5-5 4 4 3-3 6 6",
  mic:"M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3ZM5 11a7 7 0 0 0 14 0M12 18v3",
  music:"M9 18V6l10-2v12M9 18a3 3 0 1 1-3-3 3 3 0 0 1 3 3ZM19 16a3 3 0 1 1-3-3 3 3 0 0 1 3 3Z",
  trophy:"M8 4h8v5a4 4 0 0 1-8 0Zm-3 1h3v3a3 3 0 0 1-3-3Zm14 0h-3v3a3 3 0 0 0 3-3ZM10 17h4M9 21h6M12 13v4",
  disc:"M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  sparkles:"M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8ZM18 15l.9 2.1L21 18l-2.1.9L18 21l-.9-2.1L15 18l2.1-.9Z",
  users:"M17 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.87M16 3.13A4 4 0 0 1 16 11",
  cal:"M4 6h16v15H4zM4 10h16M8 3v4M16 3v4",
  clock:"M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7v5l3 2",
  pin:"M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11Zm0-8.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
  star:"M12 3l2.9 6 6.1.9-4.5 4.3 1.1 6.1L12 17.5 6.4 20.3l1.1-6.1L3 9.9 9.1 9Z",
  globe:"M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM3 12h18M12 3c2.5 2.6 2.5 15.4 0 18M12 3C9.5 5.6 9.5 18.4 12 21",
  arrowLeft:"M19 12H5M11 18l-6-6 6-6", eye:"M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  layers:"M12 3l9 5-9 5-9-5ZM3 13l9 5 9-5", tag:"M20 12l-8 8-8-8V4h8ZM8 8h.01",
  eyeoff:"M4 4l16 16M10.6 5.2A9.4 9.4 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-2.6 3.4M6.3 7.7A16.8 16.8 0 0 0 2 12s3.6 7 10 7a9.6 9.6 0 0 0 3.4-.6",
};
function Ic({ n, s = 16, style }) {
  return React.createElement("svg", { width: s, height: s, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor",
    strokeWidth: 1.9, strokeLinecap: "round", strokeLinejoin: "round", style, "aria-hidden": true },
    React.createElement("path", { d: P[n] || P.sparkles }));
}

const COLORS = { amber:{bg:"#fef3c7",text:"#b45309",border:"#fde68a",solid:"#fbbf24"},green:{bg:"#dcfce7",text:"#15803d",border:"#bbf7d0",solid:"#4ade80"},purple:{bg:"#f3e8ff",text:"#7e22ce",border:"#e9d5ff",solid:"#c084fc"},blue:{bg:"#dbeafe",text:"#1d4ed8",border:"#bfdbfe",solid:"#60a5fa"},rose:{bg:"#ffe4e6",text:"#be123c",border:"#fecdd3",solid:"#fb7185"},sky:{bg:"#e0f2fe",text:"#0369a1",border:"#bae6fd",solid:"#38bdf8"},orange:{bg:"#ffedd5",text:"#c2410c",border:"#fed7aa",solid:"#fb923c"},teal:{bg:"#ccfbf1",text:"#0f766e",border:"#99f6e4",solid:"#2dd4bf"},indigo:{bg:"#e0e7ff",text:"#4338ca",border:"#c7d2fe",solid:"#818cf8"},pink:{bg:"#fce7f3",text:"#be185d",border:"#fbcfe8",solid:"#f472b6"},emerald:{bg:"#d1fae5",text:"#047857",border:"#a7f3d0",solid:"#34d399"},violet:{bg:"#ede9fe",text:"#6d28d9",border:"#ddd6fe",solid:"#a78bfa"} };
const COLOR_KEYS = Object.keys(COLORS);
const col = k => COLORS[k] || { bg:"#F7F4EA", text:"#5F624F", border:"#E6DFC8", solid:"#E6DFC8" };

const BEHAVIOURS = [
  { value:"standard", label:"Standard night", icon:"sparkles", blurb:"No extra tools — just a normal event." },
  { value:"quiz", label:"Quiz", icon:"trophy", blurb:"Adds rounds, teams and scoring." },
  { value:"bingo", label:"Bingo", icon:"disc", blurb:"Adds bingo cards and number calling." },
  { value:"karaoke", label:"Karaoke", icon:"mic", blurb:"Adds a singer sign-up list." },
  { value:"music_act", label:"Live music", icon:"music", blurb:"Adds act details and set times." },
  { value:"private", label:"Private hire", icon:"users", blurb:"For bookings of the room by one group." },
];
const bh = v => BEHAVIOURS.find(b => b.value === v) || BEHAVIOURS[0];

const GROUPING = [
  { value:"per_event", label:"Each date books separately", blurb:"Every date gets its own page on the website." },
  { value:"per_subtype", label:"One page per sub-category", blurb:"All dates of e.g. Quiz share one page with a date picker." },
  { value:"per_type", label:"One page for the whole category", blurb:"All events in this category share a single page." },
];

/* Plain-English help copy — one line per field, written for someone who never uses websites */
const HELP = {
  name:"The short name your team sees in lists and on the rota. Keep it to one or two words, like “Quiz”.",
  catName:"The group this sits in, like “Games” or “Music”. Customers never see this — it just keeps your lists tidy.",
  title:"The heading customers read on the website when they book. It can be longer and friendlier, e.g. “Thursday Quiz Night”.",
  defaultTitle:"When you add a new event of this kind, the name is filled in for you. You can still change it for a one-off.",
  tagline:"One short line under the title on the website that sells the night. Think of what you would shout across the bar.",
  colour:"Only for you and your team — the colour this shows as in your lists and calendar. It does not appear on the website.",
  image:"The photo or poster used on the website whenever an event of this kind has no picture of its own.",
  behaviour:"Tells the system what extra tools to switch on — quiz rounds, bingo numbers, a karaoke sign-up sheet, and so on.",
  bookable:"On: customers can reserve a place online. Off: they must ring or turn up (you can still add bookings by hand).",
  host:"Tick if someone has to run this night. You will be asked who is hosting each time you schedule one.",
  seating:"Tick if guests are given tables. Leave it off for stand-up nights so you are not asked to allocate seats.",
  payment:"Tick if people pay when booking. You then set the price below.",
  price:"What one person pays to book. Leave at 0 if the night is free but you still want names.",
  grouping:"How these events are shown on the website: one page each, one page per sub-category, or one page for the whole category.",
  badges:"Short facts shown on the booking page, e.g. “Free entry” or “Thursdays 7pm”. Two or three is plenty.",
  badgeTitle:"The bold words on the badge — short, like “Free entry”.",
  badgeDesc:"Optional extra detail in smaller text next to it, like “8pm start”.",
  badgeIcon:"The little picture on the badge. Pick whatever looks closest.",
};

function InfoTip({ text, label, align }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const away = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    const esc = e => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("pointerdown", away); document.addEventListener("keydown", esc);
    return () => { document.removeEventListener("pointerdown", away); document.removeEventListener("keydown", esc); };
  }, [open]);
  return React.createElement("span", { className:"tipwrap", ref },
    React.createElement("button", { type:"button", className:"tipbtn", "aria-expanded":open,
      "aria-label":`What does ${label} mean?`, onClick:() => setOpen(!open),
      onMouseEnter:() => setOpen(true), onMouseLeave:() => setOpen(false) },
      React.createElement("svg", { width:11, height:11, viewBox:"0 0 24 24", fill:"none", stroke:"currentColor", strokeWidth:2.6, strokeLinecap:"round" },
        React.createElement("path", { d:"M12 11v6" }), React.createElement("path", { d:"M12 7h.01" }))),
    open && React.createElement("span", { className:"tippop" + (align === "end" ? " end" : ""), role:"tooltip" }, text));
}

function Field({ label, help, required, error, hint, children }) {
  return React.createElement("div", { className:"field" },
    React.createElement("div", { className:"lab" }, label,
      required && React.createElement("span", { className:"req" }, "required"),
      help && React.createElement(InfoTip, { text:help, label })),
    children,
    hint && React.createElement("p", { className:"hint" }, hint),
    error && React.createElement("p", { className:"err" }, error));
}

const DS = window.BarApp || {};
function TextIn(props) { return DS.Input ? React.createElement(DS.Input, props) : React.createElement("input", { className:"inp", ...props }); }
function Btn({ variant, size, className, children, ...rest }) {
  const cls = [className, (!variant || variant === "default") && "ec-green"].filter(Boolean).join(" ") || undefined;
  return DS.Button ? React.createElement(DS.Button, { variant, size, className: cls, ...rest }, children)
    : React.createElement("button", { className:"btn btn-primary", ...rest }, children);
}
function AreaIn(props) { return React.createElement("textarea", { className:"ta", ...props }); }

function Toggle({ label, help, sub, value, onChange }) {
  return React.createElement("div", { style:{ position:"relative" } },
    React.createElement("button", { type:"button", className:"toggle", "aria-pressed":!!value, onClick:() => onChange(!value) },
      React.createElement("span", { className:"tt" },
        React.createElement("b", null, label),
        sub && React.createElement("span", null, sub)),
      React.createElement("span", { className:"sw" }, React.createElement("i", null))),
    help && React.createElement("span", { style:{ position:"absolute", top:11, left:0, transform:"translateX(0)", visibility:"hidden" } }));
}

function ToggleWithTip({ label, help, sub, value, onChange }) {
  return React.createElement("div", { className:"field" },
    React.createElement("div", { className:"lab" }, label, React.createElement(InfoTip, { text:help, label })),
    React.createElement("button", { type:"button", className:"toggle", "aria-pressed":!!value, onClick:() => onChange(!value) },
      React.createElement("span", { className:"tt" }, React.createElement("b", null, value ? (sub?.on || "Yes") : (sub?.off || "No")),
        React.createElement("span", null, value ? (sub?.onHint || "") : (sub?.offHint || ""))),
      React.createElement("span", { className:"sw" }, React.createElement("i", null))));
}

function Swatches({ value, onChange }) {
  return React.createElement("div", { className:"swatches" }, COLOR_KEYS.map(k =>
    React.createElement("button", { key:k, type:"button", "aria-pressed":value === k, "aria-label":k,
      style:{ background:col(k).solid }, onClick:() => onChange(k) },
      value === k && React.createElement(Ic, { n:"check", s:14, style:{ color:"#fff" } }))));
}

function BehaviourPicker({ value, onChange }) {
  return React.createElement("div", { className:"opt-grid" }, BEHAVIOURS.map(b =>
    React.createElement("button", { key:b.value, type:"button", className:"opt", "aria-pressed":value === b.value, onClick:() => onChange(b.value) },
      React.createElement(Ic, { n:b.icon, s:18 }),
      React.createElement("span", null, React.createElement("b", null, b.label), React.createElement("span", null, b.blurb)))));
}

function GroupingPicker({ value, onChange }) {
  return React.createElement("div", { style:{ display:"flex", flexDirection:"column", gap:9 } }, GROUPING.map(g =>
    React.createElement("button", { key:g.value, type:"button", className:"opt", "aria-pressed":value === g.value, onClick:() => onChange(g.value) },
      React.createElement(Ic, { n:value === g.value ? "check" : "globe", s:18 }),
      React.createElement("span", null, React.createElement("b", null, g.label), React.createElement("span", null, g.blurb)))));
}

function Section({ n, title, blurb, action, children, open: openProp = true, collapsible = true }) {
  const [open, setOpen] = useState(openProp);
  return React.createElement("section", { className:"sect" },
    React.createElement("header", null,
      React.createElement("button", { type:"button", onClick:() => collapsible && setOpen(!open),
        style:{ display:"flex", alignItems:"center", gap:10, flex:1, background:"none", border:0, padding:0, textAlign:"left", minWidth:0 } },
        n && React.createElement("span", { className:"n" }, n),
        React.createElement("span", { style:{ minWidth:0 } },
          React.createElement("h3", { className:"blk" }, title),
          blurb && React.createElement("p", null, blurb))),
      action,
      collapsible && React.createElement(Ic, { n:"chevron", s:16, style:{ transform:open ? "rotate(180deg)" : "none", transition:"transform .2s", color:"#5F624F", flex:"none" } })),
    open && React.createElement("div", { className:"body" }, children));
}

function BadgeList({ badges, onAdd, onRemove }) {
  return React.createElement("div", { style:{ display:"flex", flexDirection:"column", gap:9 } },
    badges.length === 0 && React.createElement("p", { className:"hint" }, "No badges yet. Most nights look good with two, like “Free entry” and “Thursdays 7pm”."),
    badges.map((b, i) => React.createElement("div", { className:"badge-row", key:i },
      React.createElement("span", { className:"bi" }, React.createElement(Ic, { n:b.icon, s:15 })),
      React.createElement("span", { className:"bt" }, React.createElement("b", null, b.title), b.desc && React.createElement("span", null, b.desc)),
      React.createElement("button", { type:"button", className:"iconbtn danger", "aria-label":`Remove badge ${b.title}`, onClick:() => onRemove(i) },
        React.createElement(Ic, { n:"trash", s:15 })))),
    React.createElement("button", { type:"button", className:"btn btn-quiet btn-sm", onClick:onAdd, style:{ alignSelf:"flex-start" } },
      React.createElement(Ic, { n:"plus", s:14 }), "Add a badge"));
}

function Sheet({ open, onClose, side, drawer, children }) {
  useEffect(() => {
    if (!open) return;
    const esc = e => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", esc);
    return () => document.removeEventListener("keydown", esc);
  }, [open, onClose]);
  if (!open) return null;
  return React.createElement("div", { className:"scrim" + (drawer ? " drawer" : ""), onClick:e => { if (e.target === e.currentTarget) onClose(); } },
    React.createElement("div", { className:"sheet" + (side ? " side" : ""), role:"dialog", "aria-modal":"true" }, children));
}

function SheetHead({ eyebrow, title, onClose }) {
  return React.createElement(React.Fragment, null,
    React.createElement("div", { className:"grab" }),
    React.createElement("div", { className:"sheet-head" },
      React.createElement("div", { style:{ flex:1, minWidth:0 } },
        React.createElement("p", { className:"eyebrow" }, eyebrow),
        React.createElement("h2", { className:"blk" }, title)),
      React.createElement("button", { type:"button", className:"iconbtn", "aria-label":"Close", onClick:onClose }, React.createElement(Ic, { n:"x", s:17 }))));
}

/* ---- sample content, mirrored from the live page ---- */
const DATA = [
  { id:1, name:"Games", colour:"purple", grouping:"per_event", subs:[
    { id:11, name:"Bingo", colour:"rose", behaviour:"bingo", title:"Music Bingo", defaultTitle:"Bingo Night",
      tagline:"Bingo with a beat. Guess the song, fill your card, win the night.", bookable:true, host:true, seating:true, payment:true, price:"5.00",
      badges:[{icon:"pin",title:"Don Fenticas",desc:"1 Regent St, Hinckley"},{icon:"user",title:"Hosted by Mike Thomas"}] },
    { id:12, name:"Quiz", colour:"violet", behaviour:"quiz", title:"Quiz Night", defaultTitle:"Thursday Quiz Night",
      tagline:"Six rounds, one winner, plenty of arguing.", bookable:true, host:true, seating:true, payment:false, price:"",
      badges:[{icon:"ticket",title:"Free Entry"},{icon:"trophy",title:"Win Prosecco"},{icon:"cal",title:"Thursdays",desc:"7:00PM"}] } ] },
  { id:2, name:"Music", colour:"teal", grouping:"per_subtype", subs:[
    { id:21, name:"Band", colour:"orange", behaviour:"music_act", title:"Live Band", defaultTitle:"Live Band", tagline:"", bookable:false, host:false, seating:false, payment:false, price:"", badges:[] },
    { id:22, name:"DJ", colour:"sky", behaviour:"music_act", title:"DJ Set", defaultTitle:"", tagline:"", bookable:false, host:false, seating:false, payment:false, price:"", badges:[] },
    { id:23, name:"Karaoke", colour:"blue", behaviour:"karaoke", title:"Karaoke Night", defaultTitle:"Karaoke", tagline:"Your song, our stage.", bookable:true, host:true, seating:false, payment:false, price:"", badges:[{icon:"mic",title:"Sing anything"}] },
    { id:24, name:"Open Mic", colour:"indigo", behaviour:"music_act", title:"Open Mic", defaultTitle:"", tagline:"", bookable:false, host:true, seating:false, payment:false, price:"", badges:[] } ] },
  { id:3, name:"Party", colour:"amber", grouping:"per_event", subs:[
    { id:31, name:"Birthday", colour:"pink", behaviour:"private", title:"Birthday Party", defaultTitle:"", tagline:"", bookable:true, host:false, seating:true, payment:false, price:"", badges:[{icon:"users",title:"Up to 40 guests"}] } ] },
  { id:4, name:"Private hire", colour:"emerald", grouping:"per_type", subs:[
    { id:41, name:"Function room", colour:"green", behaviour:"private", title:"Hire the function room", defaultTitle:"", tagline:"The whole room, just for you.", bookable:true, host:false, seating:true, payment:true, price:"150.00", badges:[{icon:"users",title:"Seats 60"},{icon:"clock",title:"4 hour slots"}] } ] },
  { id:5, name:"Sports", colour:"green", grouping:"per_event", subs:[
    { id:51, name:"Screening", colour:"emerald", behaviour:"standard", title:"Big screen", defaultTitle:"", tagline:"", bookable:false, host:false, seating:true, payment:false, price:"", badges:[] } ] },
];

/* plain-language facts for one sub-category */
function facts(s) {
  const out = [{ icon:bh(s.behaviour).icon, text:bh(s.behaviour).label, on:false }];
  out.push(s.bookable ? { icon:"globe", text:"Books online", on:true } : { icon:"eyeoff", text:"Not online", on:false });
  if (s.host) out.push({ icon:"user", text:"Needs a host", on:false });
  if (s.seating) out.push({ icon:"chair", text:"Table seating", on:false });
  out.push(s.payment ? { icon:"note", text:`£${s.price || "0"} per person`, on:false } : { icon:"note", text:"Free entry", on:false });
  return out;
}
function Facts({ s, max = 9 }) {
  const f = facts(s);
  return React.createElement("div", { style:{ display:"flex", flexWrap:"wrap", gap:6 } },
    f.slice(0, max).map((x, i) => React.createElement("span", { className:"tag" + (x.on ? " on" : ""), key:i },
      React.createElement(Ic, { n:x.icon, s:13 }), x.text)),
    f.length > max && React.createElement("span", { className:"tag" }, `+${f.length - max} more`));
}

/* short always-visible help lines — the info button carries the longer version */
const HINT = {
  name:"One or two words. Team only.",
  title:"What customers read when they book.",
  defaultTitle:"Saves retyping it every week.",
  tagline:"One line, on the website under the title.",
  colour:"Team only — never shown to customers.",
  image:"Optional. Used when an event has no picture.",
  behaviour:"Decides which extra tools you get.",
  price:"What one person pays to book.",
  badges:"Two or three short facts is plenty.",
  grouping:"Changes how the website lists these events.",
};

Object.assign(window, { HINT, Btn, DS, Ic, P, COLORS, COLOR_KEYS, col, BEHAVIOURS, bh, GROUPING, HELP, InfoTip, Field, TextIn, AreaIn,
  Toggle, ToggleWithTip, Swatches, BehaviourPicker, GroupingPicker, Section, BadgeList, Sheet, SheetHead, DATA, facts, Facts });
